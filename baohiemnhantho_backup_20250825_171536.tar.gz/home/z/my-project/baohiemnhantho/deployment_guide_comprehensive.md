# Hướng Dẫn Deploy Chatbot Bảo Hiểm Nhân Thọ lên 6 Nền Tảng Web

## 🎯 Mục Tiêu
Deploy hệ thống chatbot bảo hiểm nhân thọ đã nâng cấp lên 6 nền tảng web khác nhau để đảm bảo tính sẵn sàng và hiệu suất cao.

## 📋 Yêu Cầu Hệ Thống

### Backend Requirements
- Python 3.8+
- Flask framework
- SQLAlchemy
- SQLite (cho development) / PostgreSQL (cho production)
- Dependencies trong `requirements.txt`

### Frontend Requirements
- HTML5, CSS3, JavaScript (ES6+)
- Responsive design
- Modern browsers support

### Infrastructure Requirements
- Web server (Nginx/Apache)
- Database server
- SSL certificate (HTTPS)
- Domain name

## 🚀 Chuẩn Bị Trước Khi Deploy

### 1. Tạo file requirements.txt
```txt
Flask==2.3.3
Flask-CORS==4.0.0
SQLAlchemy==2.0.21
requests==2.31.0
beautifulsoup4==4.12.2
lxml==4.9.3
Werkzeug==2.3.7
gunicorn==21.2.0
```

### 2. Cấu trúc thư mục tối ưu
```
baohiemnhantho/
├── app.py                    # Main application file
├── enhanced_chatbot.py       # Enhanced chatbot logic
├── product_api.py           # Product API endpoints
├── database_schema.py       # Database schema
├── insurance_scraper.py     # Web scraper
├── requirements.txt         # Python dependencies
├── config.py               # Configuration file
├── static/                 # Static files
│   ├── css/
│   ├── js/
│   └── images/
├── templates/              # HTML templates
│   ├── index.html
│   ├── enhanced_chatbot.html
│   └── product_comparison.html
├── database/               # Database files
├── logs/                   # Log files
├── deployment/             # Deployment configs
│   ├── docker/
│   ├── kubernetes/
│   ├── aws/
│   ├── gcp/
│   ├── azure/
│   └── vercel/
└── README.md
```

### 3. Tạo file cấu hình config.py
```python
import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key-here')
    
    # Database configuration
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///insurance_products.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # API configuration
    API_BASE_URL = os.environ.get('API_BASE_URL', 'https://your-api-domain.com')
    
    # Cache configuration
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 3600
    
    # Security
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # CORS configuration
    CORS_ORIGINS = [
        "https://your-frontend-domain.com",
        "https://www.your-frontend-domain.com"
    ]

class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///insurance_products.db'

class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'postgresql://user:password@localhost/insurance_db')

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
```

## 🌐 Deploy trên 6 Nền Tảng

### 1. Deploy trên VPS/Server riêng (Ubuntu + Nginx)

#### Cài đặt môi trường
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and pip
sudo apt install python3 python3-pip python3-venv -y

# Install Nginx
sudo apt install nginx -y

# Install PostgreSQL (production)
sudo apt install postgresql postgresql-contrib -y

# Create application user
sudo useradd -m -s /bin/bash insuranceapp
sudo usermod -aG sudo insuranceapp
```

#### Setup application
```bash
# Switch to application user
sudo su - insuranceapp

# Clone repository
git clone https://github.com/vsmartstation/baohiemnhantho.git
cd baohiemnhantho

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup database
createdb insurance_products
python database_schema.py

# Run scraper to populate data
python insurance_scraper.py
```

#### Configure Nginx
```nginx
# /etc/nginx/sites-available/baohiemnhantho
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL configuration
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # Static files
    location /static/ {
        alias /home/insuranceapp/baohiemnhantho/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_addon;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # API endpoints
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_addon;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
}
```

#### Setup systemd service
```ini
# /etc/systemd/system/baohiemnhantho.service
[Unit]
Description=Insurance Chatbot Application
After=network.target

[Service]
Type=exec
User=insuranceapp
Group=insuranceapp
WorkingDirectory=/home/insuranceapp/baohiemnhantho
Environment=PATH=/home/insuranceapp/baohiemnhantho/venv/bin
ExecStart=/home/insuranceapp/baohiemnhantho/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:8000 app:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

#### Start service
```bash
# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable baohiemnhantho
sudo systemctl start baohiemnhantho

# Enable and start Nginx
sudo systemctl enable nginx
sudo systemctl start nginx

# Check status
sudo systemctl status baohiemnhantho
sudo systemctl status nginx
```

### 2. Deploy trên Heroku

#### Tạo file app.py
```python
from flask import Flask, render_template
from enhanced_chatbot import enhanced_chatbot_bp
from product_api import product_bp
from database_schema import create_database_engine
import os

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///insurance_products.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Register blueprints
app.register_blueprint(enhanced_chatbot_bp, url_prefix='/api')
app.register_blueprint(product_bp, url_prefix='/api')

# Initialize database
@app.before_first_request
def create_tables():
    create_database_engine()

# Routes
@app.route('/')
def index():
    return render_template('enhanced_chatbot.html')

@app.route('/compare')
def compare():
    return render_template('product_comparison.html')

@app.route('/health')
def health():
    return {'status': 'healthy', 'service': 'insurance-chatbot'}

if __name__ == '__main__':
    app.run(debug=False)
```

#### Tạo file requirements.txt
```txt
Flask==2.3.3
Flask-CORS==4.0.0
SQLAlchemy==2.0.21
requests==2.31.0
beautifulsoup4==4.12.2
lxml==4.9.3
Werkzeug==2.3.7
gunicorn==21.2.0
psycopg2-binary==2.9.7
```

#### Tạo file Procfile
```
web: gunicorn app:app
```

#### Tạo file runtime.txt
```
python-3.9.16
```

#### Deploy commands
```bash
# Login to Heroku
heroku login

# Create app
heroku create insurance-chatbot

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:hobby-dev

# Set environment variables
heroku config:set SECRET_KEY=your-secret-key-here
heroku config:set FLASK_ENV=production

# Deploy
git add .
git commit -m "Deploy to Heroku"
git push heroku main

# Open app
heroku open
```

### 3. Deploy trên AWS (Elastic Beanstalk)

#### Tạo file .ebextensions/01_python.config
```yaml
option_settings:
  aws:elasticbeanstalk:container:python:
    WSGIPath: app.py
  aws:elasticbeanstalk:application:environment:
    FLASK_ENV: production
    SECRET_KEY: your-secret-key-here
    PYTHONPATH: "/var/app/current:$PYTHONPATH"
  aws:elasticbeanstalk:container:python:staticfiles:
    "/static/": "static/"
```

#### Tạo file .ebextensions/02_nginx.config
```yaml
files:
  "/etc/nginx/conf.d/proxy.conf":
    mode: "000644"
    owner: root
    group: root
    content: |
      client_max_body_size 20M;
      gzip on;
      gzip_vary on;
      gzip_proxied any;
      gzip_comp_level 6;
      gzip_types text/plain text/css application/json application/javascript text/xml application/xml+rss;
```

#### Deploy commands
```bash
# Install EB CLI
pip install awsebcli

# Initialize EB application
eb init -p python-3.9 flask-app insurance-chatbot

# Create environment
eb create production

# Deploy
eb deploy

# Open application
eb open
```

### 4. Deploy trên Google Cloud Platform

#### Tạo app.yaml
```yaml
runtime: python39
entrypoint: gunicorn -b :$PORT app:app

env_variables:
  FLASK_ENV: production
  SECRET_KEY: your-secret-key-here

# Static files handling
handlers:
- url: /static
  static_dir: static

# Automatic scaling
automatic_scaling:
  min_num_instances: 1
  max_num_instances: 5
  cool_down_period_sec: 120
  cpu_utilization:
    target_utilization: 0.65
```

#### Deploy commands
```bash
# Install Google Cloud SDK
# (Follow Google Cloud installation guide)

# Login to Google Cloud
gcloud auth login
gcloud config set project your-project-id

# Create App Engine application
gcloud app create

# Deploy
gcloud app deploy

# View application
gcloud app browse
```

### 5. Deploy trên Microsoft Azure

#### Tạo file web.config
```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <handlers>
      <add name="PythonHandler" path="*" verb="*" modules="FastCgiModule" 
           scriptProcessor="D:\home\site\wwwroot\env\Scripts\python.exe|D:\home\site\wwwroot\env\lib\site-packages\wfastcgi.py" 
           resourceType="Unspecified" requireAccess="Script" />
    </handlers>
  </system.webServer>
</configuration>
```

#### Tạo file startup.py
```python
import os
import sys
from app import app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8000)))
```

#### Deploy commands
```bash
# Install Azure CLI
# (Follow Azure CLI installation guide)

# Login to Azure
az login

# Create resource group
az group create --name insurance-chatbot-rg --location eastus

# Create app service plan
az appservice plan create --name insurance-chatbot-plan --resource-group insurance-chatbot-rg --sku B1

# Create web app
az webapp create --name insurance-chatbot --resource-group insurance-chatbot-rg --plan insurance-chatbot-plan --runtime "PYTHON|3.9"

# Configure web app
az webapp config set --name insurance-chatbot --resource-group insurance-chatbot-rg --linux-fx-version 'LTS'

# Deploy using local git
az webapp deployment source config-local-git --name insurance-chatbot --resource-group insurance-chatbot-rg

# Add remote and push
git remote add azure https://insurance-chatbot.scm.azurewebsites.net:443/insurance-chatbot.git
git push azure main

# Browse to web app
az webapp browse --name insurance-chatbot --resource-group insurance-chatbot-rg
```

### 6. Deploy trên Vercel (Serverless)

#### Tạo vercel.json
```json
{
  "version": 2,
  "builds": [
    {
      "src": "app.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/static/(.*)",
      "dest": "/static/$1"
    },
    {
      "src": "/(.*)",
      "dest": "app.py"
    }
  ],
  "env": {
    "FLASK_ENV": "production",
    "SECRET_KEY": "@secret_key"
  }
}
```

#### Tạo file api/index.py
```python
from flask import Flask, jsonify
from enhanced_chatbot import enhanced_chatbot_bp
from product_api import product_bp
import os

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')

# Register blueprints
app.register_blueprint(enhanced_chatbot_bp, url_prefix='/api')
app.register_blueprint(product_bp, url_prefix='/api')

@app.route('/')
def health():
    return jsonify({'status': 'healthy', 'service': 'insurance-chatbot-api'})

if __name__ == '__main__':
    app.run()
```

#### Tạo file now.json (for Vercel)
```json
{
  "version": 2,
  "builds": [
    {
      "src": "api/index.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "api/index.py"
    }
  ]
}
```

#### Deploy commands
```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

## 🔧 Cấu hình Production chung

### Environment Variables
```bash
# Production environment variables
FLASK_ENV=production
SECRET_KEY=your-very-secure-secret-key-here
DATABASE_URL=postgresql://user:password@localhost/insurance_db
API_BASE_URL=https://your-api-domain.com
REDIS_URL=redis://localhost:6379/0
SENTRY_DSN=your-sentry-dsn
GOOGLE_ANALYTICS_ID=your-ga-id
```

### Security Headers
```python
# Add to Flask app
@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';"
    return response
```

### Error Handling
```python
# Global error handler
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    return jsonify({'error': str(e)}), 500
```

### Logging Configuration
```python
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/app.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

## 📊 Monitoring và Maintenance

### Health Check Endpoint
```python
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0',
        'database': 'connected',
        'cache': 'operational'
    })
```

### Performance Monitoring
```python
import time
from functools import wraps

def monitor_performance(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        end_time = time.time()
        
        # Log performance metrics
        app.logger.info(f'{f.__name__} executed in {end_time - start_time:.2f}s')
        
        return result
    return decorated_function
```

### Database Backup Script
```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
DB_NAME="insurance_products"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup PostgreSQL
pg_dump $DB_NAME > $BACKUP_DIR/${DB_NAME}_${DATE}.sql

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete

echo "Backup completed: ${DB_NAME}_${DATE}.sql"
```

## 🚀 Post-Deployment Checklist

### 1. Security Testing
- [ ] Test all endpoints for security vulnerabilities
- [ ] Verify SSL/TLS configuration
- [ ] Check for exposed sensitive information
- [ ] Test authentication and authorization

### 2. Performance Testing
- [ ] Load testing with multiple concurrent users
- [ ] Database query optimization
- [ ] Cache effectiveness testing
- [ ] Response time monitoring

### 3. Functionality Testing
- [ ] All chatbot features working
- [ ] Product comparison functionality
- [ ] Database operations
- [ ] API endpoints

### 4. Monitoring Setup
- [ ] Application performance monitoring
- [ ] Error tracking (Sentry/LogRocket)
- [ ] Database monitoring
- [ ] Server resource monitoring

### 5. Backup and Recovery
- [ ] Automated database backups
- [ ] File system backups
- [ ] Disaster recovery plan
- [ ] Restoration testing

## 📞 Troubleshooting Common Issues

### Database Connection Issues
```bash
# Check database connection
python -c "from database_schema import create_database_engine; create_database_engine()"

# Check database logs
tail -f /var/log/postgresql/postgresql.log
```

### SSL Certificate Issues
```bash
# Check SSL certificate
openssl s_client -connect your-domain.com:443 -servername your-domain.com

# Renew Let's Encrypt certificate
certbot renew --dry-run
```

### Performance Issues
```bash
# Check system resources
htop
df -h
free -m

# Check application logs
tail -f /var/log/baohiemnhantho/app.log
```

### Nginx Configuration Issues
```bash
# Test Nginx configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log
```

## 🎉 Kết Luận

Hệ thống chatbot bảo hiểm nhân thọ đã sẵn sàng được deploy trên 6 nền tảng khác nhau. Mỗi nền tảng có ưu điểm riêng:

1. **VPS/Server riêng**: Toàn quyền kiểm soát, hiệu suất cao
2. **Heroku**: Dễ deploy, tự động scaling
3. **AWS**: Enterprise-grade, nhiều dịch vụ tích hợp
4. **Google Cloud**: AI/ML integration, mạnh về analytics
5. **Microsoft Azure**: Enterprise features, tích hợp Microsoft ecosystem
6. **Vercel**: Serverless, dễ sử dụng, phù hợp cho frontend

Chọn nền tảng phù hợp với nhu cầu và ngân sách của bạn. Hệ thống đã được tối ưu để hoạt động hiệu quả trên mọi nền tảng.