from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import json
import re
import time
import hashlib
from functools import wraps
from datetime import datetime, timedelta
import threading
from collections import defaultdict

enhanced_chatbot_bp = Blueprint('enhanced_chatbot', __name__)

class EnhancedInsuranceChatbot:
    def __init__(self):
        # Enhanced knowledge base with more detailed information
        self.knowledge_base = {
            "basic_concepts": {
                "bảo hiểm nhân thọ": {
                    "definition": "Bảo hiểm nhân thọ là hợp đồng giữa bạn và công ty bảo hiểm, trong đó công ty cam kết chi trả một khoản tiền cho người thụ hưởng khi bạn qua đời hoặc khi hợp đồng đáo hạn.",
                    "purpose": [
                        "Bảo vệ tài chính cho gia đình khi bạn không còn",
                        "Tích lũy dài hạn cho hưu trí",
                        "Đầu tư sinh lời thông qua các quỹ",
                        "Đạt được các mục tiêu tài chính cụ thể"
                    ],
                    "benefits": [
                        "An tâm tuyệt đối cho tương lai",
                        "Bảo vệ người thân yêu",
                        "Giảm thiểu rủi ro tài chính",
                        "Kế hoạch tài chính dài hạn"
                    ]
                },
                "phí bảo hiểm": {
                    "definition": "Phí bảo hiểm là số tiền bạn phải đóng định kỳ (hàng tháng, quý, năm) để duy trì hợp đồng bảo hiểm.",
                    "factors": [
                        "Tuổi của người được bảo hiểm",
                        "Sức khỏe và nghề nghiệp",
                        "Số tiền bảo hiểm",
                        "Thời hạn hợp đồng",
                        "Loại bảo hiểm và rider bổ sung"
                    ],
                    "payment_options": [
                        "Đóng theo tháng (linh hoạt)",
                        "Đóng theo quý (tiện lợi)",
                        "Đóng theo năm (tiết kiệm)",
                        "Đóng một lần (ưu đãi)"
                    ]
                },
                "số tiền bảo hiểm": {
                    "definition": "Số tiền bảo hiểm là khoản tiền mà công ty bảo hiểm sẽ chi trả cho người thụ hưởng khi xảy ra sự kiện bảo hiểm.",
                    "calculation": "Thường dựa trên 5-10 lần thu nhập hàng năm, cộng với các khoản nợ và chi phí gia đình",
                    "importance": "Đảm bảo đủ tài chính để người thân duy trì cuộc sống khi bạn không còn"
                },
                "người thụ hưởng": {
                    "definition": "Người thụ hưởng là người được chỉ định để nhận số tiền bảo hiểm khi bạn qua đời.",
                    "types": [
                        "Người thụ hưởng quyền định (vợ/chồng, con cái, cha mẹ)",
                        "Người thụ hưởng chỉ định (bạn bè, người thân khác)"
                    ],
                    "considerations": [
                        "Nên chọn người có quan hệ huyết thống",
                        "Có thể chỉ định nhiều người thụ hưởng",
                        "Có thể thay đổi người thụ hưởng bất kỳ lúc nào"
                    ]
                },
                "giá trị hoàn lại": {
                    "definition": "Giá trị hoàn lại là số tiền bạn có thể nhận được nếu chấm dứt hợp đồng bảo hiểm trước thời hạn.",
                    "factors": [
                        "Thời gian đã đóng phí",
                        "Loại sản phẩm bảo hiểm",
                        "Thị trường đầu tư (đối với bảo hiểm liên kết đầu tư)",
                        "Phí chấm dứt hợp đồng"
                    ]
                }
            },
            "insurance_companies": {
                "prudential": {
                    "name": "Prudential Việt Nam",
                    "founded": 1848,
                    "vietnam_entry": 1999,
                    "market_position": "Top 1",
                    "strengths": [
                        "175 năm kinh nghiệm toàn cầu",
                        "Sản phẩm đa dạng, sáng tạo",
                        "Dịch vụ khách hàng xuất sắc",
                        "Mạng lưới rộng khắp",
                        "Công nghệ số tiên tiến"
                    ],
                    "popular_products": [
                        "PRUlink - Bảo hiểm liên kết đầu tư",
                        "PRUlove - Bảo hiểm nhân thọ truyền thống",
                        "PRUhealth - Bảo hiểm sức khỏe",
                        "PRUeducation - Bảo hiểm giáo dục"
                    ],
                    "contact": {
                        "website": "https://www.prudential.com.vn",
                        "hotline": "1800 588 826",
                        "branches": "63 tỉnh thành"
                    }
                },
                "manulife": {
                    "name": "Manulife Việt Nam",
                    "founded": 1887,
                    "vietnam_entry": 1999,
                    "market_position": "Top 3",
                    "strengths": [
                        "Công ty Canada uy tín",
                        "Sản phẩm đầu tư mạnh",
                        "Fintech và digital banking",
                        "Chương trình wellness",
                        "Dịch vụ cao cấp"
                    ],
                    "popular_products": [
                        "Manulife - Bảo hiểm liên kết đầu tư",
                        "Manulife Heritage - Bảo hiểm truyền thống",
                        "Manulife Health - Bảo hiểm sức khỏe",
                        "Manulife Education - Bảo hiểm giáo dục"
                    ],
                    "contact": {
                        "website": "https://www.manulife.com.vn",
                        "hotline": "1900 6069",
                        "branches": "50+ tỉnh thành"
                    }
                },
                "baoviet": {
                    "name": "Bảo Việt",
                    "founded": 1965,
                    "vietnam_entry": 1965,
                    "market_position": "Top 5",
                    "strengths": [
                        "Tập đoàn tài chính nhà nước",
                        "Uy tín cao nhất Việt Nam",
                        "Mạng lưới rộng khắp 63 tỉnh thành",
                        "Sản phẩm phù hợp người Việt",
                        "Giá cả cạnh tranh"
                    ],
                    "popular_products": [
                        "Bảo Việt An Tâm - Bảo hiểm nhân thọ",
                        "Bảo Việt Tích Lũy - Bảo hiểm tiết kiệm",
                        "Bảo Việt Sức Khỏe - Bảo hiểm y tế",
                        "Bảo Việt Giáo Dục - Bảo hiểm học đường"
                    ],
                    "contact": {
                        "website": "https://www.baoviet.com.vn",
                        "hotline": "1900 55 88 99",
                        "branches": "63 tỉnh thành"
                    }
                },
                "daiichi": {
                    "name": "Dai-ichi Việt Nam",
                    "founded": 1902,
                    "vietnam_entry": 2007,
                    "market_position": "Top 4",
                    "strengths": [
                        "Công ty Nhật Bản chất lượng cao",
                        "Dịch vụ khách hàng xuất sắc",
                        "Sản phẩm phù hợp với người Việt",
                        "Công nghệ hiện đại",
                        "Đội ngũ tư vấn chuyên nghiệp"
                    ],
                    "popular_products": [
                        "An Gia Thịnh Vượng - Bảo hiểm nhân thọ",
                        "Tương Lai Tươi Sáng - Bảo hiểm giáo dục",
                        "Sức Khỏe Vàng - Bảo hiểm sức khỏe",
                        "An Tâm Hưu Trí - Bảo hiểm hưu trí"
                    ],
                    "contact": {
                        "website": "https://www.dai-ichi-life.com.vn",
                        "hotline": "1900 5454 15",
                        "branches": "63 tỉnh thành"
                    }
                },
                "aia": {
                    "name": "AIA Việt Nam",
                    "founded": 1919,
                    "vietnam_entry": 2000,
                    "market_position": "Top 6",
                    "strengths": [
                        "Tập đoàn Anh uy tín",
                        "Sản phẩm sáng tạo",
                        "Chương trình wellness và health",
                        "Công nghệ số tiên tiến",
                        "Dịch vụ khách hàng 24/7"
                    ],
                    "popular_products": [
                        "AIA Vitality - Bảo hiểm sức khỏe",
                        "AIA Future Builder - Bảo hiểm giáo dục",
                        "AIA Retirement - Bảo hiểm hưu trí",
                        "AIA Legacy - Bảo hiểm truyền thống"
                    ],
                    "contact": {
                        "website": "https://www.aia.com.vn",
                        "hotline": "1900 2727 28",
                        "branches": "45+ tỉnh thành"
                    }
                },
                "chubb": {
                    "name": "Chubb Life Việt Nam",
                    "founded": 1882,
                    "vietnam_entry": 2005,
                    "market_position": "Top 8",
                    "strengths": [
                        "Công ty Mỹ uy tín",
                        "Sản phẩm đa dạng",
                        "Dịch vụ nhanh chóng",
                        "Giá cả cạnh tranh",
                        "Đội ngũ chuyên nghiệp"
                    ],
                    "popular_products": [
                        "Chubb Life Protection - Bảo hiểm nhân thọ",
                        "Chubb Life Education - Bảo hiểm giáo dục",
                        "Chubb Life Health - Bảo hiểm sức khỏe",
                        "Chubb Life Retirement - Bảo hiểm hưu trí"
                    ],
                    "contact": {
                        "website": "https://www.chubblife.com.vn",
                        "hotline": "1900 5858 88",
                        "branches": "40+ tỉnh thành"
                    }
                }
            },
            "insurance_types": {
                "bảo hiểm nhân thọ truyền thống": {
                    "description": "Loại bảo hiểm cơ bản nhất, tập trung vào bảo vệ tài chính cho gia đình khi người được bảo hiểm qua đời.",
                    "pros": [
                        "Phí bảo hiểm thấp",
                        "Đơn giản, dễ hiểu",
                        "Bảo vệ tài chính hiệu quả",
                        "Không rủi ro đầu tư",
                        "Đảm bảo quyền lợi cố định"
                    ],
                    "cons": [
                        "Không có giá trị đầu tư",
                        "Không hoàn lại phí nếu không có sự cố",
                        "Quyền lợi giới hạn",
                        "Lạm phát có thể làm giảm giá trị"
                    ],
                    "suitable_for": "Người trẻ, thu nhập hạn chế, cần bảo vệ tài chính cơ bản",
                    "examples": [
                        "PRUlove - Prudential",
                        "Bảo Việt An Tâm - Bảo Việt",
                        "An Gia Thịnh Vượng - Dai-ichi"
                    ]
                },
                "bảo hiểm nhân thọ đầu tư": {
                    "description": "Kết hợp bảo hiểm và đầu tư, một phần phí bảo hiểm được đầu tư vào các quỹ.",
                    "pros": [
                        "Có khả năng sinh lời",
                        "Linh hoạt trong đầu tư",
                        "Có thể rút tiền khi cần",
                        "Bảo vệ đồng thời đầu tư",
                        "Tiếp cận các quỹ đầu tư chuyên nghiệp"
                    ],
                    "cons": [
                        "Phí cao hơn",
                        "Rủi ro đầu tư",
                        "Phức tạp hơn",
                        "Quyền lợi không đảm bảo",
                        "Phụ thuộc vào thị trường"
                    ],
                    "suitable_for": "Người có thu nhập ổn định, hiểu biết về đầu tư",
                    "examples": [
                        "PRUlink - Prudential",
                        "Manulife - Manulife",
                        "AIA Vitality - AIA"
                    ]
                },
                "bảo hiểm nhân thọ hỗn hợp": {
                    "description": "Kết hợp bảo vệ và tích lũy, có giá trị hoàn lại khi đáo hạn.",
                    "pros": [
                        "Vừa bảo vệ vừa tích lũy",
                        "Có giá trị hoàn lại",
                        "Ổn định",
                        "Lợi nhuận đảm bảo",
                        "Phù hợp với người thích an toàn"
                    ],
                    "cons": [
                        "Phí cao hơn bảo hiểm truyền thống",
                        "Lợi nhuận thấp",
                        "Thời hạn hợp đồng dài",
                        "Linh hoạt hạn chế"
                    ],
                    "suitable_for": "Người muốn vừa bảo vệ vừa tiết kiệm",
                    "examples": [
                        "PRUlove Plus - Prudential",
                        "Bảo Việt Tích Lũy - Bảo Việt",
                        "Tương Lai Tươi Sáng - Dai-ichi"
                    ]
                }
            },
            "calculation_guide": {
                "income_multiple": "Mức bảo hiểm khuyến nghị = 5-10 lần thu nhập hàng năm",
                "debt_coverage": "Cần tính thêm các khoản nợ hiện tại (vay nhà, vay xe, thẻ tín dụng)",
                "family_expenses": "Chi phí sinh hoạt gia đình trong 5-10 năm tới",
                "education_fund": "Quỹ giáo dục cho con (nếu có)",
                "emergency_fund": "Quỹ khẩn cấp 6-12 tháng chi phí sinh hoạt",
                "detailed_formula": {
                    "step1": "Thu nhập hàng năm × 10 = Mức bảo hiểm cơ bản",
                    "step2": "+ Các khoản nợ hiện tại",
                    "step3": "+ Chi phí giáo dục con cái",
                    "step4": "+ Quỹ khẩn cấp 6 tháng",
                    "step5": "- Tài sản hiện có (nếu có)",
                    "step6": "= Tổng mức bảo hiểm cần thiết"
                }
            },
            "product_comparison": {
                "comparison_criteria": [
                    "Phí bảo hiểm",
                    "Quyền lợi bảo vệ",
                    "Giá trị hoàn lại",
                    "Rider bổ sung",
                    "Thời hạn hợp đồng",
                    "Điều khoản đáo hạn",
                    "Quy trình giải quyết quyền lợi",
                    "Uy tín công ty",
                    "Dịch vụ khách hàng"
                ],
                "company_strengths": {
                    "prudential": "Sản phẩm đa dạng, dịch vụ xuất sắc",
                    "manulife": "Đầu tư mạnh, fintech tiên tiến",
                    "baoviet": "Uy tín nhà nước, giá cả cạnh tranh",
                    "daiichi": "Chất lượng Nhật Bản, dịch vụ tốt",
                    "aia": "Sản phẩm sáng tạo, wellness program",
                    "chubb": "Giá cả cạnh tranh, dịch vụ nhanh"
                }
            }
        }
        
        # Enhanced conversation starters
        self.conversation_starters = [
            "👋 Xin chào! Tôi là trợ lý tư vấn bảo hiểm nhân thọ thế hệ mới.",
            "🚀 Tôi có thể giúp bạn:",
            "• 📚 Hiểu các khái niệm cơ bản về bảo hiểm nhân thọ",
            "• 🔍 So sánh sản phẩm từ các công ty bảo hiểm hàng đầu",
            "• 🧮 Tính toán nhu cầu bảo hiểm phù hợp với bạn",
            "• 🏆 Tìm hiểu về các công ty bảo hiểm uy tín",
            "• 💡 Giải đáp thắc mắc về quy trình và điều khoản",
            "",
            "🎯 Bạn muốn tìm hiểu về điều gì hôm nay?"
        ]
        
        # Performance optimization
        self.response_cache = {}
        self.cache_expiry = 3600  # 1 hour
        self.performance_metrics = {
            'total_requests': 0,
            'cache_hits': 0,
            'average_response_time': 0,
            'response_times': []
        }
        
        # Initialize cache cleaner
        self.start_cache_cleaner()
    
    def start_cache_cleaner(self):
        """Start background thread to clean expired cache entries"""
        def clean_cache():
            while True:
                time.sleep(300)  # Clean every 5 minutes
                self.clean_expired_cache()
        
        thread = threading.Thread(target=clean_cache, daemon=True)
        thread.start()
    
    def clean_expired_cache(self):
        """Remove expired entries from cache"""
        current_time = time.time()
        expired_keys = [
            key for key, (data, timestamp) in self.response_cache.items()
            if current_time - timestamp > self.cache_expiry
        ]
        
        for key in expired_keys:
            del self.response_cache[key]
        
        if expired_keys:
            print(f"Cleaned {len(expired_keys)} expired cache entries")
    
    def get_cache_key(self, user_message, conversation_history=None):
        """Generate cache key for message"""
        # Create a simple hash of the message
        message_hash = hashlib.md5(user_message.lower().encode()).hexdigest()
        return f"response_{message_hash}"
    
    def get_cached_response(self, cache_key):
        """Get response from cache if available and not expired"""
        if cache_key in self.response_cache:
            data, timestamp = self.response_cache[cache_key]
            if time.time() - timestamp < self.cache_expiry:
                self.performance_metrics['cache_hits'] += 1
                return data
            else:
                # Remove expired entry
                del self.response_cache[cache_key]
        return None
    
    def cache_response(self, cache_key, response):
        """Cache response with timestamp"""
        self.response_cache[cache_key] = (response, time.time())
    
    def update_performance_metrics(self, response_time):
        """Update performance metrics"""
        self.performance_metrics['total_requests'] += 1
        self.performance_metrics['response_times'].append(response_time)
        
        # Keep only last 100 response times
        if len(self.performance_metrics['response_times']) > 100:
            self.performance_metrics['response_times'] = self.performance_metrics['response_times'][-100:]
        
        # Calculate average response time
        if self.performance_metrics['response_times']:
            avg_time = sum(self.performance_metrics['response_times']) / len(self.performance_metrics['response_times'])
            self.performance_metrics['average_response_time'] = avg_time
    
    def get_performance_stats(self):
        """Get current performance statistics"""
        total_requests = self.performance_metrics['total_requests']
        cache_hits = self.performance_metrics['cache_hits']
        cache_hit_rate = (cache_hits / total_requests * 100) if total_requests > 0 else 0
        
        return {
            'total_requests': total_requests,
            'cache_hits': cache_hits,
            'cache_hit_rate': round(cache_hit_rate, 2),
            'average_response_time': round(self.performance_metrics['average_response_time'], 2),
            'cache_size': len(self.response_cache)
        }
    
    def get_response(self, user_message, conversation_history=None):
        start_time = time.time()
        
        # Check cache first
        cache_key = self.get_cache_key(user_message, conversation_history)
        cached_response = self.get_cached_response(cache_key)
        
        if cached_response:
            response_time = time.time() - start_time
            self.update_performance_metrics(response_time)
            return cached_response
        
        # Generate response
        response = self.generate_response(user_message, conversation_history)
        
        # Cache the response
        self.cache_response(cache_key, response)
        
        # Update performance metrics
        response_time = time.time() - start_time
        self.update_performance_metrics(response_time)
        
        return response
    
    def generate_response(self, user_message, conversation_history=None):
        user_message = user_message.lower().strip()
        
        # Greeting responses
        if any(greeting in user_message for greeting in ["xin chào", "hello", "hi", "chào"]):
            return "\n".join(self.conversation_starters)
        
        # Basic concept explanations
        for concept, details in self.knowledge_base["basic_concepts"].items():
            if concept in user_message:
                return self.format_concept_response(concept, details)
        
        # Company information
        for company_key, company_info in self.knowledge_base["insurance_companies"].items():
            if company_key in user_message or company_info["name"].lower() in user_message:
                return self.format_company_response(company_info)
        
        # Insurance type comparisons
        if any(keyword in user_message for keyword in ["so sánh", "loại bảo hiểm", "khác nhau", "nên chọn"]):
            return self.compare_insurance_types()
        
        # Product comparison
        if any(keyword in user_message for keyword in ["so sánh sản phẩm", "sản phẩm", "bảo hiểm nào"]):
            return self.compare_products()
        
        # Company comparison
        if any(keyword in user_message for keyword in ["công ty nào tốt nhất", "nên chọn công ty", "top công ty"]):
            return self.compare_companies()
        
        # Need calculation
        if any(keyword in user_message for keyword in ["tính toán", "nhu cầu", "bao nhiêu", "mức bảo hiểm"]):
            return self.guide_calculation()
        
        # Age and income based advice
        age_match = re.search(r'(\d+)\s*tuổi', user_message)
        income_match = re.search(r'(\d+)\s*(triệu|tr)', user_message)
        
        if age_match or income_match:
            return self.personalized_advice(age_match, income_match, user_message)
        
        # General advice
        if any(keyword in user_message for keyword in ["tư vấn", "nên mua", "bắt đầu", "không biết"]):
            return self.general_advice()
        
        # Default response
        return self.default_response()
    
    def format_concept_response(self, concept, details):
        """Format concept explanation with enhanced details"""
        response = f"📚 **{concept.title()}:**\n\n"
        response += f"**Định nghĩa:** {details['definition']}\n\n"
        
        if 'purpose' in details:
            response += "**Mục đích chính:**\n"
            for purpose in details['purpose']:
                response += f"• {purpose}\n"
            response += "\n"
        
        if 'benefits' in details:
            response += "**Lợi ích nổi bật:**\n"
            for benefit in details['benefits']:
                response += f"• {benefit}\n"
            response += "\n"
        
        if 'factors' in details:
            response += "**Yếu tố ảnh hưởng:**\n"
            for factor in details['factors']:
                response += f"• {factor}\n"
            response += "\n"
        
        if 'payment_options' in details:
            response += "**Hình thức thanh toán:**\n"
            for option in details['payment_options']:
                response += f"• {option}\n"
            response += "\n"
        
        if 'considerations' in details:
            response += "**Lưu ý quan trọng:**\n"
            for consideration in details['considerations']:
                response += f"• {consideration}\n"
            response += "\n"
        
        response += "Bạn có muốn tìm hiểu thêm về khái niệm nào khác không?"
        return response
    
    def format_company_response(self, company_info):
        """Format company information with enhanced details"""
        response = f"🏢 **{company_info['name']}:**\n\n"
        
        response += f"**Năm thành lập:** {company_info['founded']} (Toàn cầu)\n"
        response += f"**Năm vào Việt Nam:** {company_info['vietnam_entry']}\n"
        response += f"**Vị trí thị trường:** {company_info['market_position']}\n\n"
        
        response += "**Ưu điểm nổi bật:**\n"
        for strength in company_info['strengths']:
            response += f"• {strength}\n"
        response += "\n"
        
        response += "**Sản phẩm phổ biến:**\n"
        for product in company_info['popular_products']:
            response += f"• {product}\n"
        response += "\n"
        
        response += "**Thông tin liên hệ:**\n"
        contact = company_info['contact']
        response += f"• Website: {contact['website']}\n"
        response += f"• Hotline: {contact['hotline']}\n"
        response += f"• Mạng lưới: {contact['branches']}\n\n"
        
        response += "Bạn muốn tìm hiểu sâu hơn về sản phẩm nào của công ty này không?"
        return response
    
    def compare_insurance_types(self):
        response = "**🔍 So Sánh Các Loại Bảo Hiểm Nhân Thọ:**\n\n"
        
        for insurance_type, details in self.knowledge_base["insurance_types"].items():
            response += f"**{insurance_type.title()}:**\n"
            response += f"{details['description']}\n\n"
            response += "✅ **Ưu điểm:**\n"
            for pro in details['pros']:
                response += f"• {pro}\n"
            response += "\n❌ **Nhược điểm:**\n"
            for con in details['cons']:
                response += f"• {con}\n"
            response += f"\n👥 **Phù hợp với:** {details['suitable_for']}\n"
            
            if 'examples' in details:
                response += "\n📋 **Ví dụ sản phẩm:**\n"
                for example in details['examples']:
                    response += f"• {example}\n"
            
            response += "\n" + "="*50 + "\n\n"
        
        response += "Bạn có muốn tôi tư vấn cụ thể dựa trên tình hình của bạn không?"
        return response
    
    def compare_products(self):
        response = "**🔍 So Sánh Sản Phẩm Bảo Hiểm Nhân Thọ:**\n\n"
        response += "Tôi đang kết nối với các công ty bảo hiểm hàng đầu Việt Nam để lấy thông tin sản phẩm mới nhất...\n\n"
        
        response += "**📊 Các công ty bảo hiểm đang được theo dõi:**\n"
        for company_key, company_info in self.knowledge_base["insurance_companies"].items():
            response += f"• **{company_info['name']}** - {company_info['market_position']}\n"
        
        response += "\n**🔎 Thông tin sẽ được so sánh:**\n"
        criteria = self.knowledge_base["product_comparison"]["comparison_criteria"]
        for criterion in criteria:
            response += f"• {criterion}\n"
        
        response += "\n**🏆 Điểm mạnh của từng công ty:**\n"
        company_strengths = self.knowledge_base["product_comparison"]["company_strengths"]
        for company_key, strength in company_strengths.items():
            company_name = self.knowledge_base["insurance_companies"][company_key]["name"]
            response += f"• **{company_name}:** {strength}\n"
        
        response += "\nBạn muốn so sánh sản phẩm của công ty nào? Hay bạn có nhu cầu cụ thể nào?"
        return response
    
    def compare_companies(self):
        response = "**🏆 Top Công Ty Bảo Hiểm Nhân Thọ Uy Tín tại Việt Nam:**\n\n"
        
        # Sort companies by market position
        companies = sorted(
            self.knowledge_base["insurance_companies"].items(),
            key=lambda x: int(x[1]["market_position"].split()[1]) if x[1]["market_position"].split()[1].isdigit() else 999
        )
        
        medals = ["🥇", "🥈", "🥉", "🏅", "🎖️", "🏵"]
        
        for i, (company_key, company_info) in enumerate(companies):
            medal = medals[i] if i < len(medals) else "📋"
            response += f"{medal} **{company_info['name']}**\n"
            response += f"⭐ **Vị trí:** {company_info['market_position']}\n"
            response += f"📅 **Năm thành lập:** {company_info['founded']} (Toàn cầu)\n"
            response += f"🇻🇳 **Năm vào VN:** {company_info['vietnam_entry']}\n\n"
            
            response += "**Ưu điểm nổi bật:**\n"
            for strength in company_info['strengths'][:3]:  # Show top 3 strengths
                response += f"• {strength}\n"
            response += "\n"
        
        response += "**💡 Lời khuyên:**\n"
        response += "• Chọn công ty có uy tín và kinh nghiệm\n"
        response += "• Xem xét mạng lưới phục vụ tại khu vực bạn sống\n"
        response += "• So sánh sản phẩm và phí bảo hiểm\n"
        response += "• Đọc kỹ đánh giá từ khách hàng hiện tại\n\n"
        
        response += "Bạn quan tâm đến công ty nào? Tôi có thể cung cấp thông tin chi tiết hơn!"
        return response
    
    def guide_calculation(self):
        calculation_guide = self.knowledge_base["calculation_guide"]
        response = "**🧮 Tính Toán Nhu Cầu Bảo Hiểm Thông Minh:**\n\n"
        
        response += "**Công thức chuẩn:**\n"
        response += f"💰 **{calculation_guide['income_multiple']}**\n\n"
        
        response += "**📋 Các yếu tố cần tính thêm:**\n"
        factors = [
            ("🏠", calculation_guide['debt_coverage']),
            ("👨‍👩‍👧‍👦", calculation_guide['family_expenses']),
            ("🎓", calculation_guide['education_fund']),
            ("🚨", calculation_guide['emergency_fund'])
        ]
        
        for emoji, factor in factors:
            response += f"{emoji} {factor}\n"
        
        response += "\n**📝 Công thức chi tiết:**\n"
        detailed_formula = calculation_guide['detailed_formula']
        for step, formula in detailed_formula.items():
            step_num = step.replace('step', '')
            response += f"**Bước {step_num}:** {formula}\n"
        
        response += "\n**📊 Ví dụ thực tế:**\n"
        response += "Thu nhập: **20 triệu/tháng** = **240 triệu/năm**\n"
        response += "Mức bảo hiểm khuyến nghị: **1.2 - 2.4 tỷ đồng**\n\n"
        
        response += "**🎯 Để tôi tính chính xác cho bạn:**\n"
        response += "Hãy chia sẻ:\n"
        response += "• Tuổi của bạn?\n"
        response += "• Thu nhập hàng tháng?\n"
        response += "• Số người phụ thuộc?\n"
        response += "• Các khoản nợ hiện tại?\n\n"
        
        response += "Tôi sẽ tính toán mức bảo hiểm phù hợp nhất cho bạn!"
        return response
    
    def personalized_advice(self, age_match, income_match, user_message):
        age = int(age_match.group(1)) if age_match else None
        income = int(income_match.group(1)) if income_match else None
        
        response = "**🎯 Tư Vấn Cá Nhân Hóa:**\n\n"
        
        if age:
            response += f"**Với độ tuổi {age}:**\n"
            if age < 25:
                response += "• Ưu tiên bảo hiểm nhân thọ truyền thống (phí thấp)\n"
                response += "• Tập trung xây dựng nền tảng tài chính\n"
                response += "• Mua sớm để hưởng phí thấp\n"
            elif age < 35:
                response += "• Có thể cân nhắc bảo hiểm hỗn hợp\n"
                response += "• Cân bằng giữa bảo vệ và tích lũy\n"
                response += "• Thêm rider bảo hiểm sức khỏe\n"
            elif age < 45:
                response += "• Nên ưu tiên bảo hiểm có giá trị hoàn lại\n"
                response += "• Chuẩn bị cho giáo dục con cái\n"
                response += "• Cân nhắc bảo hiểm đầu tư\n"
            else:
                response += "• Tập trung vào bảo hiểm hưu trí\n"
                response += "• Đảm bảo an toàn tài chính\n"
                response += "• Chuẩn bị cho giai đoạn nghỉ hưu\n"
            response += "\n"
        
        if income:
            annual_income = income * 12
            min_coverage = annual_income * 5
            max_coverage = annual_income * 10
            response += f"**Với thu nhập {income} triệu/tháng:**\n"
            response += f"• Thu nhập năm: {annual_income} triệu\n"
            response += f"• Mức bảo hiểm khuyến nghị: {min_coverage/1000:.1f} - {max_coverage/1000:.1f} tỷ đồng\n"
            
            # Additional advice based on income level
            if income < 10:
                response += "• Nên bắt đầu với bảo hiểm truyền thống\n"
                response += "• Tập trung vào bảo vệ cơ bản\n"
            elif income < 20:
                response += "• Có thể cân nhắc bảo hiểm hỗn hợp\n"
                response += "• Thêm các rider cần thiết\n"
            else:
                response += "• Có thể đầu tư vào bảo hiểm liên kết đầu tư\n"
                response += "• Xây dựng danh mục đầu tư đa dạng\n"
            response += "\n"
        
        response += "**📋 Khuyến nghị sản phẩm:**\n"
        
        # Recommend products based on age and income
        if age and income:
            if age < 30 and income < 15:
                response += "• Prudential PRUlove (truyền thống)\n"
                response += "• Bảo Việt An Tâm (giá cả cạnh tranh)\n"
            elif age < 40 and income >= 15:
                response += "• Manulife (đầu tư mạnh)\n"
                response += "• Dai-ichi An Gia Thịnh Vượng (chất lượng)\n"
            else:
                response += "• AIA Retirement (hưu trí)\n"
                response += "• Bảo Việt Tích Lũy (an toàn)\n"
        
        response += "\nBạn có gia đình (vợ/chồng, con) chưa? Điều này sẽ ảnh hưởng đến mức bảo hiểm cần thiết."
        
        return response
    
    def general_advice(self):
        return """**💡 Lời Khuyên Chung Về Bảo Hiểm Nhân Thọ:**

**🕐 Khi nào nên mua:**
• Càng sớm càng tốt (phí thấp hơn)
• Khi có người phụ thuộc tài chính
• Khi có thu nhập ổn định
• Khi còn trẻ và khỏe mạnh

**🎯 Nguyên tắc vàng:**
• Mua sớm, mua đủ, mua đúng
• Ưu tiên bảo vệ trước, đầu tư sau
• Đọc kỹ điều khoản trước khi ký
• Chọn công ty uy tín

**⚠️ Lưu ý quan trọng:**
• Khai báo sức khỏe trung thực
• Lựa chọn công ty uy tín
• Xem xét khả năng tài chính dài hạn
• Hiểu rõ các điều khoản loại trừ

**📝 Quy trình mua bảo hiểm:**
1. Tìm hiểu và so sánh các công ty
2. Tính toán nhu cầu bảo hiểm
3. Chọn sản phẩm phù hợp
4. Đọc kỹ điều khoản hợp đồng
5. Khai báo thông tin trung thực
6. Ký kết hợp đồng và đóng phí

Bạn đang ở giai đoạn nào trong cuộc đời? Tôi có thể tư vấn cụ thể hơn."""
    
    def default_response(self):
        return """🤖 **Tôi có thể giúp bạn với:**

**📚 Kiến thức cơ bản:**
• "Bảo hiểm nhân thọ là gì?"
• "Phí bảo hiểm là gì?"
• "Người thụ hưởng là ai?"
• "Giá trị hoàn lại là gì?"

**🧮 Tính toán nhu cầu:**
• "Tính nhu cầu bảo hiểm của tôi"
• "Tôi cần mua bao nhiêu bảo hiểm?"
• "Tôi 30 tuổi, thu nhập 20 triệu nên mua gì?"
• "Tính bảo hiểm cho gia đình"

**🔍 So sánh sản phẩm:**
• "So sánh các loại bảo hiểm"
• "So sánh sản phẩm bảo hiểm"
• "Công ty bảo hiểm nào tốt nhất?"
• "Sản phẩm của Prudential như thế nào?"

**🏢 Thông tin công ty:**
• "Prudential Việt Nam"
• "Manulife Việt Nam"
• "Bảo Việt"
• "Dai-ichi Việt Nam"
• "AIA Việt Nam"

**💡 Tư vấn chuyên sâu:**
• "Nên mua bảo hiểm khi nào?"
• "Cách chọn sản phẩm phù hợp"
• "Điều khoản cần lưu ý"
• "Quy trình bồi thường"

Hãy hỏi tôi bất kỳ điều gì về bảo hiểm nhân thọ nhé! 🎯"""

# Initialize enhanced chatbot
enhanced_chatbot = EnhancedInsuranceChatbot()

def cache_response(func):
    """Decorator to cache responses"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@enhanced_chatbot_bp.route('/enhanced-chat', methods=['POST'])
@cross_origin()
def enhanced_chat():
    try:
        start_time = time.time()
        data = request.get_json()
        user_message = data.get('message', '')
        conversation_history = data.get('history', [])
        
        if not user_message:
            return jsonify({'error': 'Tin nhắn không được để trống'}), 400
        
        response = enhanced_chatbot.get_response(user_message, conversation_history)
        
        # Calculate response time
        response_time = time.time() - start_time
        
        return jsonify({
            'response': response,
            'timestamp': str(int(time.time())),
            'response_time_ms': round(response_time * 1000, 2),
            'performance_stats': enhanced_chatbot.get_performance_stats()
        })
    
    except Exception as e:
        return jsonify({'error': f'Lỗi xử lý: {str(e)}'}), 500

@enhanced_chatbot_bp.route('/enhanced-health', methods=['GET'])
@cross_origin()
def enhanced_health():
    return jsonify({
        'status': 'healthy', 
        'service': 'Enhanced Insurance Chatbot',
        'performance_stats': enhanced_chatbot.get_performance_stats(),
        'cache_size': len(enhanced_chatbot.response_cache),
        'uptime': time.time()
    })

@enhanced_chatbot_bp.route('/performance-stats', methods=['GET'])
@cross_origin()
def performance_stats():
    return jsonify({
        'performance': enhanced_chatbot.get_performance_stats(),
        'cache_info': {
            'size': len(enhanced_chatbot.response_cache),
            'expiry_seconds': enhanced_chatbot.cache_expiry
        },
        'knowledge_base': {
            'companies': len(enhanced_chatbot.knowledge_base['insurance_companies']),
            'insurance_types': len(enhanced_chatbot.knowledge_base['insurance_types']),
            'concepts': len(enhanced_chatbot.knowledge_base['basic_concepts'])
        }
    })

@enhanced_chatbot_bp.route('/clear-cache', methods=['POST'])
@cross_origin()
def clear_cache():
    try:
        cache_size_before = len(enhanced_chatbot.response_cache)
        enhanced_chatbot.response_cache.clear()
        return jsonify({
            'success': True,
            'message': f'Cache cleared successfully. Removed {cache_size_before} entries.',
            'cache_size_after': 0
        })
    except Exception as e:
        return jsonify({'error': f'Error clearing cache: {str(e)}'}), 500