"""
API endpoints for Insurance Products Management
Các API endpoint để quản lý và truy vấn thông tin sản phẩm bảo hiểm
"""

from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from sqlalchemy import create_engine, or_, and_, desc, func
from sqlalchemy.orm import sessionmaker
from database_schema import Base, InsuranceCompany, InsuranceProduct, InsuranceCategory, PremiumPlan, ProductBenefit, ProductComparison
import json
from datetime import datetime, timedelta
import hashlib
import re

# Create blueprint
product_bp = Blueprint('product_api', __name__)

# Database setup
engine = create_engine('sqlite:///insurance_products.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

def get_db_session():
    """Get database session"""
    return Session()

def format_company_data(company):
    """Format company data for API response"""
    return {
        'id': company.id,
        'name': company.name,
        'name_en': company.name_en,
        'founded_year': company.founded_year,
        'vietnam_entry_year': company.vietnam_entry_year,
        'market_position': company.market_position,
        'website': company.website,
        'hotline': company.hotline,
        'description': company.description,
        'strengths': company.strengths or [],
        'rating': company.rating,
        'total_products': len(company.products) if company.products else 0
    }

def format_product_data(product):
    """Format product data for API response"""
    return {
        'id': product.id,
        'name': product.name,
        'name_en': product.name_en,
        'code': product.code,
        'slug': product.slug,
        'short_description': product.short_description,
        'full_description': product.full_description,
        'product_type': product.product_type,
        'target_customers': product.target_customers or [],
        'min_age': product.min_age,
        'max_age': product.max_age,
        'min_coverage_amount': product.min_coverage_amount,
        'max_coverage_amount': product.max_coverage_amount,
        'policy_term_min': product.policy_term_min,
        'policy_term_max': product.policy_term_max,
        'premium_payment_methods': product.premium_payment_methods or [],
        'pros': product.pros or [],
        'cons': product.cons or [],
        'benefits': product.benefits or [],
        'features': product.features or [],
        'rating': product.rating,
        'number_of_reviews': product.number_of_reviews,
        'is_popular': product.is_popular,
        'is_recommended': product.is_recommended,
        'view_count': product.view_count,
        'company': {
            'id': product.company.id,
            'name': product.company.name,
            'market_position': product.company.market_position
        } if product.company else None,
        'category': {
            'id': product.category.id,
            'name': product.category.name
        } if product.category else None,
        'premium_plans': [
            {
                'id': plan.id,
                'name': plan.name,
                'age_from': plan.age_from,
                'age_to': plan.age_to,
                'coverage_amount': plan.coverage_amount,
                'premium_monthly': plan.premium_monthly,
                'premium_yearly': plan.premium_yearly,
                'guaranteed_return': plan.guaranteed_return
            } for plan in product.premium_plans
        ] if product.premium_plans else []
    }

@product_bp.route('/companies', methods=['GET'])
@cross_origin()
def get_companies():
    """Get all insurance companies"""
    try:
        session = get_db_session()
        
        # Get query parameters
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        sort_by = request.args.get('sort_by', 'name')
        sort_order = request.args.get('sort_order', 'asc')
        search = request.args.get('search', '')
        
        # Build query
        query = session.query(InsuranceCompany).filter(InsuranceCompany.is_active == True)
        
        # Apply search filter
        if search:
            query = query.filter(
                or_(
                    InsuranceCompany.name.ilike(f'%{search}%'),
                    InsuranceCompany.name_en.ilike(f'%{search}%'),
                    InsuranceCompany.description.ilike(f'%{search}%')
                )
            )
        
        # Apply sorting
        if sort_order == 'desc':
            query = query.order_by(desc(getattr(InsuranceCompany, sort_by)))
        else:
            query = query.order_by(getattr(InsuranceCompany, sort_by))
        
        # Apply pagination
        total = query.count()
        companies = query.offset((page - 1) * per_page).limit(per_page).all()
        
        # Format response
        response = {
            'success': True,
            'data': [format_company_data(company) for company in companies],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/companies/<int:company_id>', methods=['GET'])
@cross_origin()
def get_company(company_id):
    """Get company details by ID"""
    try:
        session = get_db_session()
        company = session.query(InsuranceCompany).filter(
            InsuranceCompany.id == company_id,
            InsuranceCompany.is_active == True
        ).first()
        
        if not company:
            session.close()
            return jsonify({'success': False, 'error': 'Company not found'}), 404
        
        response = {
            'success': True,
            'data': format_company_data(company)
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/products', methods=['GET'])
@cross_origin()
def get_products():
    """Get all insurance products with filtering and sorting"""
    try:
        session = get_db_session()
        
        # Get query parameters
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        sort_by = request.args.get('sort_by', 'name')
        sort_order = request.args.get('sort_order', 'asc')
        search = request.args.get('search', '')
        company_id = request.args.get('company_id', type=int)
        category_id = request.args.get('category_id', type=int)
        product_type = request.args.get('product_type', '')
        min_age = request.args.get('min_age', type=int)
        max_age = request.args.get('max_age', type=int)
        min_coverage = request.args.get('min_coverage', type=float)
        max_coverage = request.args.get('max_coverage', type=float)
        is_popular = request.args.get('is_popular', type=bool)
        is_recommended = request.args.get('is_recommended', type=bool)
        
        # Build query
        query = session.query(InsuranceProduct).filter(InsuranceProduct.is_active == True)
        
        # Apply filters
        if search:
            query = query.filter(
                or_(
                    InsuranceProduct.name.ilike(f'%{search}%'),
                    InsuranceProduct.name_en.ilike(f'%{search}%'),
                    InsuranceProduct.short_description.ilike(f'%{search}%'),
                    InsuranceProduct.full_description.ilike(f'%{search}%')
                )
            )
        
        if company_id:
            query = query.filter(InsuranceProduct.company_id == company_id)
        
        if category_id:
            query = query.filter(InsuranceProduct.category_id == category_id)
        
        if product_type:
            query = query.filter(InsuranceProduct.product_type == product_type)
        
        if min_age is not None:
            query = query.filter(InsuranceProduct.min_age <= min_age)
        
        if max_age is not None:
            query = query.filter(InsuranceProduct.max_age >= max_age)
        
        if min_coverage is not None:
            query = query.filter(InsuranceProduct.min_coverage_amount >= min_coverage)
        
        if max_coverage is not None:
            query = query.filter(InsuranceProduct.max_coverage_amount <= max_coverage)
        
        if is_popular is not None:
            query = query.filter(InsuranceProduct.is_popular == is_popular)
        
        if is_recommended is not None:
            query = query.filter(InsuranceProduct.is_recommended == is_recommended)
        
        # Apply sorting
        if sort_order == 'desc':
            query = query.order_by(desc(getattr(InsuranceProduct, sort_by)))
        else:
            query = query.order_by(getattr(InsuranceProduct, sort_by))
        
        # Apply pagination
        total = query.count()
        products = query.offset((page - 1) * per_page).limit(per_page).all()
        
        # Format response
        response = {
            'success': True,
            'data': [format_product_data(product) for product in products],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            },
            'filters': {
                'search': search,
                'company_id': company_id,
                'category_id': category_id,
                'product_type': product_type,
                'min_age': min_age,
                'max_age': max_age,
                'min_coverage': min_coverage,
                'max_coverage': max_coverage,
                'is_popular': is_popular,
                'is_recommended': is_recommended
            }
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/products/<int:product_id>', methods=['GET'])
@cross_origin()
def get_product(product_id):
    """Get product details by ID"""
    try:
        session = get_db_session()
        product = session.query(InsuranceProduct).filter(
            InsuranceProduct.id == product_id,
            InsuranceProduct.is_active == True
        ).first()
        
        if not product:
            session.close()
            return jsonify({'success': False, 'error': 'Product not found'}), 404
        
        # Increment view count
        product.view_count += 1
        session.commit()
        
        response = {
            'success': True,
            'data': format_product_data(product)
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/products/<int:product_id>/benefits', methods=['GET'])
@cross_origin()
def get_product_benefits(product_id):
    """Get product benefits by product ID"""
    try:
        session = get_db_session()
        
        benefits = session.query(ProductBenefit).filter(
            ProductBenefit.product_id == product_id,
            ProductBenefit.is_active == True
        ).order_by(ProductBenefit.sort_order).all()
        
        benefits_data = []
        for benefit in benefits:
            benefits_data.append({
                'id': benefit.id,
                'name': benefit.name,
                'description': benefit.description,
                'benefit_type': benefit.benefit_type,
                'coverage_amount': benefit.coverage_amount,
                'coverage_percentage': benefit.coverage_percentage,
                'waiting_period': benefit.waiting_period,
                'conditions': benefit.conditions or [],
                'exclusions': benefit.exclusions or [],
                'is_mandatory': benefit.is_mandatory
            })
        
        response = {
            'success': True,
            'data': benefits_data
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/categories', methods=['GET'])
@cross_origin()
def get_categories():
    """Get all insurance categories"""
    try:
        session = get_db_session()
        categories = session.query(InsuranceCategory).filter(
            InsuranceCategory.is_active == True
        ).order_by(InsuranceCategory.sort_order).all()
        
        categories_data = []
        for category in categories:
            categories_data.append({
                'id': category.id,
                'name': category.name,
                'name_en': category.name_en,
                'description': category.description,
                'icon': category.icon,
                'color': category.color,
                'parent_id': category.parent_id
            })
        
        response = {
            'success': True,
            'data': categories_data
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/compare', methods=['POST'])
@cross_origin()
def compare_products():
    """Compare multiple insurance products"""
    try:
        data = request.get_json()
        product_ids = data.get('product_ids', [])
        criteria = data.get('criteria', [])
        user_preferences = data.get('user_preferences', {})
        
        if not product_ids or len(product_ids) < 2:
            return jsonify({'success': False, 'error': 'At least 2 products are required for comparison'}), 400
        
        if len(product_ids) > 5:
            return jsonify({'success': False, 'error': 'Maximum 5 products can be compared at once'}), 400
        
        session = get_db_session()
        
        # Get products
        products = session.query(InsuranceProduct).filter(
            InsuranceProduct.id.in_(product_ids),
            InsuranceProduct.is_active == True
        ).all()
        
        if len(products) != len(product_ids):
            session.close()
            return jsonify({'success': False, 'error': 'One or more products not found'}), 404
        
        # Generate comparison result
        comparison_result = generate_comparison_result(products, criteria, user_preferences)
        
        # Save comparison to database
        session_id = generate_session_id()
        comparison = ProductComparison(
            session_id=session_id,
            products=product_ids,
            comparison_criteria=criteria,
            comparison_result=comparison_result,
            user_preferences=user_preferences,
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        session.add(comparison)
        session.commit()
        
        response = {
            'success': True,
            'data': {
                'comparison_id': comparison.id,
                'session_id': session_id,
                'products': [format_product_data(product) for product in products],
                'comparison_result': comparison_result,
                'expires_at': comparison.expires_at.isoformat()
            }
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/compare/<session_id>', methods=['GET'])
@cross_origin()
def get_comparison(session_id):
    """Get saved comparison by session ID"""
    try:
        session = get_db_session()
        
        comparison = session.query(ProductComparison).filter(
            ProductComparison.session_id == session_id,
            ProductComparison.expires_at > datetime.utcnow()
        ).first()
        
        if not comparison:
            session.close()
            return jsonify({'success': False, 'error': 'Comparison not found or expired'}), 404
        
        # Get products
        products = session.query(InsuranceProduct).filter(
            InsuranceProduct.id.in_(comparison.products),
            InsuranceProduct.is_active == True
        ).all()
        
        response = {
            'success': True,
            'data': {
                'comparison_id': comparison.id,
                'session_id': comparison.session_id,
                'products': [format_product_data(product) for product in products],
                'comparison_result': comparison.comparison_result,
                'user_preferences': comparison.user_preferences,
                'expires_at': comparison.expires_at.isoformat()
            }
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/recommend', methods=['POST'])
@cross_origin()
def recommend_products():
    """Recommend products based on user preferences"""
    try:
        data = request.get_json()
        user_preferences = data.get('user_preferences', {})
        
        # Extract user preferences
        age = user_preferences.get('age', 30)
        income = user_preferences.get('income', 0)  # Monthly income in million VND
        budget = user_preferences.get('budget', 0)  # Monthly budget in thousand VND
        coverage_amount = user_preferences.get('coverage_amount', 0)  # Desired coverage in million VND
        product_type = user_preferences.get('product_type', '')
        priorities = user_preferences.get('priorities', [])  # ['price', 'coverage', 'benefits', 'company']
        
        session = get_db_session()
        
        # Build recommendation query
        query = session.query(InsuranceProduct).filter(InsuranceProduct.is_active == True)
        
        # Apply age filter
        if age:
            query = query.filter(
                and_(
                    InsuranceProduct.min_age <= age,
                    InsuranceProduct.max_age >= age
                )
            )
        
        # Apply product type filter
        if product_type:
            query = query.filter(InsuranceProduct.product_type == product_type)
        
        # Apply coverage amount filter
        if coverage_amount > 0:
            query = query.filter(
                and_(
                    InsuranceProduct.min_coverage_amount <= coverage_amount,
                    InsuranceProduct.max_coverage_amount >= coverage_amount
                )
            )
        
        # Get all matching products
        products = query.all()
        
        # Score products based on user preferences
        scored_products = []
        for product in products:
            score = calculate_product_score(product, user_preferences)
            scored_products.append((product, score))
        
        # Sort by score and get top recommendations
        scored_products.sort(key=lambda x: x[1], reverse=True)
        top_recommendations = scored_products[:5]
        
        # Format response
        recommendations = []
        for product, score in top_recommendations:
            product_data = format_product_data(product)
            product_data['recommendation_score'] = round(score, 2)
            product_data['recommendation_reason'] = get_recommendation_reason(product, user_preferences)
            recommendations.append(product_data)
        
        response = {
            'success': True,
            'data': {
                'recommendations': recommendations,
                'user_preferences': user_preferences,
                'total_products_considered': len(products)
            }
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/search', methods=['GET'])
@cross_origin()
def search_products():
    """Search products with advanced filters"""
    try:
        session = get_db_session()
        
        # Get search parameters
        query = request.args.get('q', '')
        filters = request.args.get('filters', '{}')
        sort_by = request.args.get('sort_by', 'relevance')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        
        try:
            filter_data = json.loads(filters)
        except:
            filter_data = {}
        
        # Build search query
        search_query = session.query(InsuranceProduct).filter(InsuranceProduct.is_active == True)
        
        if query:
            # Full-text search
            search_conditions = []
            search_terms = query.split()
            
            for term in search_terms:
                term_condition = or_(
                    InsuranceProduct.name.ilike(f'%{term}%'),
                    InsuranceProduct.name_en.ilike(f'%{term}%'),
                    InsuranceProduct.short_description.ilike(f'%{term}%'),
                    InsuranceProduct.full_description.ilike(f'%{term}%')
                )
                search_conditions.append(term_condition)
            
            if search_conditions:
                search_query = search_query.filter(and_(*search_conditions))
        
        # Apply additional filters
        if 'company_id' in filter_data:
            search_query = search_query.filter(InsuranceProduct.company_id == filter_data['company_id'])
        
        if 'category_id' in filter_data:
            search_query = search_query.filter(InsuranceProduct.category_id == filter_data['category_id'])
        
        if 'product_type' in filter_data:
            search_query = search_query.filter(InsuranceProduct.product_type == filter_data['product_type'])
        
        if 'min_price' in filter_data and 'max_price' in filter_data:
            # Filter by premium plans
            search_query = search_query.join(InsuranceProduct.premium_plans).filter(
                and_(
                    PremiumPlan.premium_monthly >= filter_data['min_price'],
                    PremiumPlan.premium_monthly <= filter_data['max_price']
                )
            )
        
        # Apply sorting
        if sort_by == 'relevance' and query:
            # Simple relevance sorting by name match
            search_query = search_query.order_by(
                func.similarity(InsuranceProduct.name, query).desc()
            )
        elif sort_by == 'price_asc':
            search_query = search_query.join(InsuranceProduct.premium_plans).order_by(PremiumPlan.premium_monthly.asc())
        elif sort_by == 'price_desc':
            search_query = search_query.join(InsuranceProduct.premium_plans).order_by(PremiumPlan.premium_monthly.desc())
        elif sort_by == 'rating':
            search_query = search_query.order_by(InsuranceProduct.rating.desc())
        elif sort_by == 'popularity':
            search_query = search_query.order_by(InsuranceProduct.view_count.desc())
        else:
            search_query = search_query.order_by(InsuranceProduct.name.asc())
        
        # Apply pagination
        total = search_query.count()
        products = search_query.offset((page - 1) * per_page).limit(per_page).all()
        
        response = {
            'success': True,
            'data': [format_product_data(product) for product in products],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            },
            'search_query': query,
            'filters': filter_data
        }
        
        session.close()
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/stats', methods=['GET'])
@cross_origin()
def get_statistics():
    """Get system statistics"""
    try:
        session = get_db_session()
        
        stats = {
            'total_companies': session.query(InsuranceCompany).filter(InsuranceCompany.is_active == True).count(),
            'total_products': session.query(InsuranceProduct).filter(InsuranceProduct.is_active == True).count(),
            'total_categories': session.query(InsuranceCategory).filter(InsuranceCategory.is_active == True).count(),
            'companies_by_market_position': {},
            'products_by_type': {},
            'top_rated_products': [],
            'most_viewed_products': []
        }
        
        # Companies by market position
        companies = session.query(InsuranceCompany).filter(InsuranceCompany.is_active == True).all()
        for company in companies:
            position = company.market_position or 'Other'
            if position not in stats['companies_by_market_position']:
                stats['companies_by_market_position'][position] = 0
            stats['companies_by_market_position'][position] += 1
        
        # Products by type
        products = session.query(InsuranceProduct).filter(InsuranceProduct.is_active == True).all()
        for product in products:
            ptype = product.product_type or 'Other'
            if ptype not in stats['products_by_type']:
                stats['products_by_type'][ptype] = 0
            stats['products_by_type'][ptype] += 1
        
        # Top rated products
        top_rated = session.query(InsuranceProduct).filter(
            InsuranceProduct.is_active == True,
            InsuranceProduct.rating.isnot(None)
        ).order_by(desc(InsuranceProduct.rating)).limit(5).all()
        
        stats['top_rated_products'] = [format_product_data(p) for p in top_rated]
        
        # Most viewed products
        most_viewed = session.query(InsuranceProduct).filter(
            InsuranceProduct.is_active == True
        ).order_by(desc(InsuranceProduct.view_count)).limit(5).all()
        
        stats['most_viewed_products'] = [format_product_data(p) for p in most_viewed]
        
        session.close()
        
        response = {
            'success': True,
            'data': stats
        }
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Helper functions
def generate_session_id():
    """Generate unique session ID"""
    return hashlib.md5(f"{datetime.utcnow().isoformat()}_{hash(str(datetime.utcnow().microsecond))}".encode()).hexdigest()

def generate_comparison_result(products, criteria, user_preferences):
    """Generate comparison result for products"""
    result = {
        'criteria': criteria,
        'products': [],
        'winner': None,
        'summary': {}
    }
    
    if not criteria:
        criteria = ['price', 'coverage', 'benefits', 'company_rating']
    
    for product in products:
        product_score = {
            'product_id': product.id,
            'product_name': product.name,
            'company_name': product.company.name if product.company else 'Unknown',
            'scores': {},
            'total_score': 0
        }
        
        # Calculate scores for each criterion
        for criterion in criteria:
            score = calculate_criterion_score(product, criterion)
            product_score['scores'][criterion] = score
            product_score['total_score'] += score
        
        result['products'].append(product_score)
    
    # Sort products by total score
    result['products'].sort(key=lambda x: x['total_score'], reverse=True)
    
    # Set winner
    if result['products']:
        result['winner'] = result['products'][0]
    
    # Generate summary
    result['summary'] = generate_comparison_summary(result['products'])
    
    return result

def calculate_criterion_score(product, criterion):
    """Calculate score for a specific criterion"""
    score = 0
    
    if criterion == 'price':
        # Lower price gets higher score
        if product.premium_plans:
            avg_premium = sum(plan.premium_monthly or 0 for plan in product.premium_plans) / len(product.premium_plans)
            score = max(0, 100 - avg_premium / 10)  # Normalize to 0-100
        else:
            score = 50
    
    elif criterion == 'coverage':
        # Higher coverage gets higher score
        if product.max_coverage_amount:
            score = min(100, product.max_coverage_amount / 100)  # Normalize to 0-100
        else:
            score = 50
    
    elif criterion == 'benefits':
        # More benefits get higher score
        benefits_count = len(product.benefits or [])
        score = min(100, benefits_count * 10)  # Normalize to 0-100
    
    elif criterion == 'company_rating':
        # Higher company rating gets higher score
        if product.company and product.company.rating:
            score = product.company.rating * 20  # Convert 1-5 to 0-100
        else:
            score = 50
    
    elif criterion == 'popularity':
        # Higher view count gets higher score
        score = min(100, product.view_count / 10)  # Normalize to 0-100
    
    return score

def calculate_product_score(product, user_preferences):
    """Calculate recommendation score for a product"""
    score = 0
    
    # Age compatibility
    age = user_preferences.get('age', 30)
    if product.min_age <= age <= product.max_age:
        score += 20
    
    # Budget compatibility
    budget = user_preferences.get('budget', 0)
    if budget > 0 and product.premium_plans:
        affordable_plans = [plan for plan in product.premium_plans if plan.premium_monthly <= budget]
        if affordable_plans:
            score += 20
    
    # Coverage compatibility
    coverage_amount = user_preferences.get('coverage_amount', 0)
    if coverage_amount > 0:
        if product.min_coverage_amount <= coverage_amount <= product.max_coverage_amount:
            score += 20
    
    # Product type preference
    preferred_type = user_preferences.get('product_type', '')
    if preferred_type and product.product_type == preferred_type:
        score += 15
    
    # Company rating
    if product.company and product.company.rating:
        score += product.company.rating * 5  # Max 25 points
    
    # Product rating
    if product.rating:
        score += product.rating * 5  # Max 25 points
    
    # Popularity bonus
    if product.is_popular:
        score += 10
    
    if product.is_recommended:
        score += 15
    
    return score

def get_recommendation_reason(product, user_preferences):
    """Generate recommendation reason for a product"""
    reasons = []
    
    age = user_preferences.get('age', 30)
    if product.min_age <= age <= product.max_age:
        reasons.append(f"Phù hợp với độ tuổi {age}")
    
    budget = user_preferences.get('budget', 0)
    if budget > 0 and product.premium_plans:
        affordable_plans = [plan for plan in product.premium_plans if plan.premium_monthly <= budget]
        if affordable_plans:
            reasons.append(f"Phù hợp với ngân sách {budget:,} VNĐ/tháng")
    
    if product.is_popular:
        reasons.append("Sản phẩm phổ biến được nhiều người lựa chọn")
    
    if product.is_recommended:
        reasons.append("Được chuyên gia khuyên dùng")
    
    if product.company and product.company.rating >= 4.5:
        reasons.append(f"Công ty {product.company.name} uy tín")
    
    return "; ".join(reasons) if reasons else "Sản phẩm phù hợp với nhu cầu của bạn"

def generate_comparison_summary(products):
    """Generate comparison summary"""
    if not products:
        return {}
    
    summary = {
        'best_value': None,
        'most_affordable': None,
        'best_coverage': None,
        'highest_rated': None
    }
    
    # Find best value (highest total score)
    best_value = max(products, key=lambda x: x['total_score'])
    summary['best_value'] = {
        'product_id': best_value['product_id'],
        'product_name': best_value['product_name'],
        'score': best_value['total_score']
    }
    
    # Find most affordable (assuming price criterion exists)
    price_products = [p for p in products if 'price' in p['scores']]
    if price_products:
        most_affordable = max(price_products, key=lambda x: x['scores']['price'])
        summary['most_affordable'] = {
            'product_id': most_affordable['product_id'],
            'product_name': most_affordable['product_name'],
            'score': most_affordable['scores']['price']
        }
    
    # Find best coverage (assuming coverage criterion exists)
    coverage_products = [p for p in products if 'coverage' in p['scores']]
    if coverage_products:
        best_coverage = max(coverage_products, key=lambda x: x['scores']['coverage'])
        summary['best_coverage'] = {
            'product_id': best_coverage['product_id'],
            'product_name': best_coverage['product_name'],
            'score': best_coverage['scores']['coverage']
        }
    
    # Find highest rated (assuming company_rating criterion exists)
    rating_products = [p for p in products if 'company_rating' in p['scores']]
    if rating_products:
        highest_rated = max(rating_products, key=lambda x: x['scores']['company_rating'])
        summary['highest_rated'] = {
            'product_id': highest_rated['product_id'],
            'product_name': highest_rated['product_name'],
            'score': highest_rated['scores']['company_rating']
        }
    
    return summary