"""
Web Scraper for Insurance Companies in Vietnam
Công cụ thu thập thông tin sản phẩm bảo hiểm từ các công ty bảo hiểm tại Việt Nam
"""

import requests
from bs4 import BeautifulSoup
import json
import time
import re
from datetime import datetime
from urllib.parse import urljoin, urlparse
import logging
from database_schema import create_database_engine, get_session, InsuranceCompany, InsuranceProduct, InsuranceCategory, PremiumPlan, ScrapingLog
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class InsuranceScraper:
    def __init__(self, database_url="sqlite:///insurance_products.db"):
        self.engine = create_database_engine(database_url)
        self.session = get_session(self.engine)
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.request_delay = 2  # Delay between requests to avoid being blocked
        self.max_retries = 3
        
        # Company configurations
        self.companies_config = {
            'prudential': {
                'name': 'Prudential Việt Nam',
                'base_url': 'https://www.prudential.com.vn',
                'product_pages': [
                    'https://www.prudential.com.vn/san-pham/bao-hiem-nhan-tho',
                    'https://www.prudential.com.vn/san-pham/bao-hiem-suc-khoe',
                    'https://www.prudential.com.vn/san-pham/bao-hiem-education'
                ],
                'product_selectors': {
                    'product_list': '.product-item, .product-card, .insurance-product',
                    'product_name': '.product-name, .title, h2, h3',
                    'product_link': 'a',
                    'description': '.description, .summary, .excerpt',
                    'price': '.price, .premium, .fee'
                }
            },
            'manulife': {
                'name': 'Manulife Việt Nam',
                'base_url': 'https://www.manulife.com.vn',
                'product_pages': [
                    'https://www.manulife.com.vn/vi/individuals/insurance',
                    'https://www.manulife.com.vn/vi/individuals/health'
                ],
                'product_selectors': {
                    'product_list': '.product-item, .card, .insurance-card',
                    'product_name': '.product-name, .title, h2, h3',
                    'product_link': 'a',
                    'description': '.description, .summary, .text',
                    'price': '.price, .premium'
                }
            },
            'baoviet': {
                'name': 'Bảo Việt',
                'base_url': 'https://www.baoviet.com.vn',
                'product_pages': [
                    'https://www.baoviet.com.vn/san-pham',
                    'https://www.baoviet.com.vn/bao-hiem-nhan-tho'
                ],
                'product_selectors': {
                    'product_list': '.product-item, .san-pham, .insurance-product',
                    'product_name': '.ten-sp, .title, h2, h3',
                    'product_link': 'a',
                    'description': '.mo-ta, .description, .summary',
                    'price': '.gia, .price, .phi'
                }
            },
            'daiichi': {
                'name': 'Dai-ichi Việt Nam',
                'base_url': 'https://www.dai-ichi-life.com.vn',
                'product_pages': [
                    'https://www.dai-ichi-life.com.vn/san-pham',
                    'https://www.dai-ichi-life.com.vn/bao-hiem-nhan-tho'
                ],
                'product_selectors': {
                    'product_list': '.product-item, .product, .insurance-product',
                    'product_name': '.product-name, .title, h2, h3',
                    'product_link': 'a',
                    'description': '.description, .summary, .excerpt',
                    'price': '.price, .premium'
                }
            },
            'aia': {
                'name': 'AIA Việt Nam',
                'base_url': 'https://www.aia.com.vn',
                'product_pages': [
                    'https://www.aia.com.vn/vi/individuals/insurance',
                    'https://www.aia.com.vn/vi/individuals/health'
                ],
                'product_selectors': {
                    'product_list': '.product-item, .card, .insurance-card',
                    'product_name': '.product-name, .title, h2, h3',
                    'product_link': 'a',
                    'description': '.description, .summary, .text',
                    'price': '.price, .premium'
                }
            }
        }
    
    def log_scraping_activity(self, source, scraping_type, status, items_scraped=0, items_updated=0, items_created=0, errors=None, execution_time=0):
        """Log scraping activity to database"""
        try:
            log_entry = ScrapingLog(
                source=source,
                scraping_type=scraping_type,
                status=status,
                items_scraped=items_scraped,
                items_updated=items_updated,
                items_created=items_created,
                errors=errors or [],
                execution_time=execution_time
            )
            self.session.add(log_entry)
            self.session.commit()
            logger.info(f"Logged scraping activity: {source} - {scraping_type} - {status}")
        except Exception as e:
            logger.error(f"Failed to log scraping activity: {str(e)}")
    
    def make_request(self, url, retries=None):
        """Make HTTP request with retry logic"""
        if retries is None:
            retries = self.max_retries
        
        for attempt in range(retries):
            try:
                response = requests.get(url, headers=self.headers, timeout=30)
                response.raise_for_status()
                return response
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{retries}): {url} - {str(e)}")
                if attempt < retries - 1:
                    time.sleep(self.request_delay * (attempt + 1))
                else:
                    logger.error(f"Request failed after {retries} attempts: {url}")
                    return None
    
    def scrape_company_info(self, company_key):
        """Scrape basic company information"""
        start_time = time.time()
        errors = []
        
        try:
            config = self.companies_config[company_key]
            base_url = config['base_url']
            
            logger.info(f"Scraping company info for: {config['name']}")
            
            # Get company homepage
            response = self.make_request(base_url)
            if not response:
                errors.append(f"Failed to fetch company homepage: {base_url}")
                self.log_scraping_activity(
                    source=company_key,
                    scraping_type='company_info',
                    status='failed',
                    errors=errors,
                    execution_time=time.time() - start_time
                )
                return False
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract company information
            company_info = {
                'name': config['name'],
                'website': base_url,
                'description': self.extract_company_description(soup),
                'strengths': self.extract_company_strengths(soup),
                'headquarters': self.extract_headquarters(soup),
                'contact_info': self.extract_contact_info(soup)
            }
            
            # Save to database
            self.save_company_info(company_key, company_info)
            
            execution_time = time.time() - start_time
            self.log_scraping_activity(
                source=company_key,
                scraping_type='company_info',
                status='success',
                items_scraped=1,
                items_created=1,
                execution_time=execution_time
            )
            
            logger.info(f"Successfully scraped company info for: {config['name']}")
            return True
            
        except Exception as e:
            errors.append(f"Error scraping company info: {str(e)}")
            execution_time = time.time() - start_time
            self.log_scraping_activity(
                source=company_key,
                scraping_type='company_info',
                status='failed',
                errors=errors,
                execution_time=execution_time
            )
            return False
    
    def scrape_products(self, company_key):
        """Scrape product information for a company"""
        start_time = time.time()
        errors = []
        products_scraped = 0
        products_updated = 0
        products_created = 0
        
        try:
            config = self.companies_config[company_key]
            logger.info(f"Scraping products for: {config['name']}")
            
            for page_url in config['product_pages']:
                try:
                    logger.info(f"Scraping products from: {page_url}")
                    
                    response = self.make_request(page_url)
                    if not response:
                        errors.append(f"Failed to fetch page: {page_url}")
                        continue
                    
                    soup = BeautifulSoup(response.content, 'html.parser')
                    
                    # Extract product links
                    product_links = self.extract_product_links(soup, page_url, config['product_selectors'])
                    
                    for product_url in product_links:
                        try:
                            product_data = self.scrape_product_details(product_url, config['product_selectors'])
                            if product_data:
                                # Save product to database
                                result = self.save_product_info(company_key, product_data)
                                if result == 'created':
                                    products_created += 1
                                elif result == 'updated':
                                    products_updated += 1
                                products_scraped += 1
                            
                            # Be respectful with delays
                            time.sleep(self.request_delay)
                            
                        except Exception as e:
                            errors.append(f"Error scraping product {product_url}: {str(e)}")
                            continue
                
                except Exception as e:
                    errors.append(f"Error scraping page {page_url}: {str(e)}")
                    continue
            
            execution_time = time.time() - start_time
            status = 'success' if products_scraped > 0 else 'partial'
            
            self.log_scraping_activity(
                source=company_key,
                scraping_type='products',
                status=status,
                items_scraped=products_scraped,
                items_updated=products_updated,
                items_created=products_created,
                errors=errors,
                execution_time=execution_time
            )
            
            logger.info(f"Scraped {products_scraped} products for {config['name']}")
            return True
            
        except Exception as e:
            errors.append(f"Error scraping products: {str(e)}")
            execution_time = time.time() - start_time
            self.log_scraping_activity(
                source=company_key,
                scraping_type='products',
                status='failed',
                errors=errors,
                execution_time=execution_time
            )
            return False
    
    def extract_company_description(self, soup):
        """Extract company description from homepage"""
        description_selectors = [
            '.about-us p',
            '.company-description p',
            '.intro p',
            '.description p',
            'meta[name="description"]'
        ]
        
        for selector in description_selectors:
            elements = soup.select(selector)
            if elements:
                if selector.startswith('meta'):
                    return elements[0].get('content', '')
                else:
                    return ' '.join([elem.get_text(strip=True) for elem in elements[:3]])
        
        return ''
    
    def extract_company_strengths(self, soup):
        """Extract company strengths"""
        strengths = []
        strength_selectors = [
            '.strengths li',
            '.advantages li',
            '.features li',
            '.why-choose-us li'
        ]
        
        for selector in strength_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text(strip=True)
                if text and len(text) > 10:
                    strengths.append(text)
        
        return strengths[:5]  # Return top 5 strengths
    
    def extract_headquarters(self, soup):
        """Extract headquarters information"""
        address_selectors = [
            '.address',
            '.contact-address',
            '.headquarters'
        ]
        
        for selector in address_selectors:
            elements = soup.select(selector)
            if elements:
                return elements[0].get_text(strip=True)
        
        return ''
    
    def extract_contact_info(self, soup):
        """Extract contact information"""
        contact_info = {}
        
        # Extract phone
        phone_selectors = [
            '.phone',
            '.hotline',
            '.tel',
            'a[href^="tel:"]'
        ]
        
        for selector in phone_selectors:
            elements = soup.select(selector)
            if elements:
                phone = elements[0].get_text(strip=True)
                if phone:
                    contact_info['phone'] = phone
                    break
        
        # Extract email
        email_selectors = [
            '.email',
            '.contact-email',
            'a[href^="mailto:"]'
        ]
        
        for selector in email_selectors:
            elements = soup.select(selector)
            if elements:
                email = elements[0].get_text(strip=True)
                if email:
                    contact_info['email'] = email
                    break
        
        return contact_info
    
    def extract_product_links(self, soup, base_url, selectors):
        """Extract product links from a page"""
        product_links = []
        
        # Try different selectors for product list
        list_selectors = selectors['product_list'].split(', ')
        
        for selector in list_selectors:
            elements = soup.select(selector)
            if elements:
                for element in elements:
                    # Find product link
                    link_element = element.select_one(selectors['product_link'])
                    if link_element and link_element.get('href'):
                        product_url = urljoin(base_url, link_element.get('href'))
                        if self.is_valid_product_url(product_url):
                            product_links.append(product_url)
                
                if product_links:
                    break
        
        return list(set(product_links))  # Remove duplicates
    
    def scrape_product_details(self, product_url, selectors):
        """Scrape detailed product information"""
        try:
            response = self.make_request(product_url)
            if not response:
                return None
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract product information
            product_data = {
                'url': product_url,
                'name': self.extract_product_name(soup, selectors),
                'description': self.extract_product_description(soup, selectors),
                'features': self.extract_product_features(soup),
                'benefits': self.extract_product_benefits(soup),
                'premium_info': self.extract_premium_info(soup),
                'eligibility': self.extract_eligibility_info(soup),
                'exclusions': self.extract_exclusions(soup)
            }
            
            return product_data
            
        except Exception as e:
            logger.error(f"Error scraping product details from {product_url}: {str(e)}")
            return None
    
    def extract_product_name(self, soup, selectors):
        """Extract product name"""
        name_selectors = selectors['product_name'].split(', ')
        
        for selector in name_selectors:
            elements = soup.select(selector)
            if elements:
                name = elements[0].get_text(strip=True)
                if name and len(name) > 5:
                    return name
        
        return ''
    
    def extract_product_description(self, soup, selectors):
        """Extract product description"""
        desc_selectors = selectors['description'].split(', ')
        
        for selector in desc_selectors:
            elements = soup.select(selector)
            if elements:
                descriptions = []
                for element in elements:
                    text = element.get_text(strip=True)
                    if text and len(text) > 20:
                        descriptions.append(text)
                
                if descriptions:
                    return ' '.join(descriptions[:3])  # Return first 3 descriptions
        
        return ''
    
    def extract_product_features(self, soup):
        """Extract product features"""
        features = []
        feature_selectors = [
            '.features li',
            '.product-features li',
            '.specifications li',
            '.key-features li'
        ]
        
        for selector in feature_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text(strip=True)
                if text and len(text) > 5:
                    features.append(text)
        
        return features[:10]  # Return top 10 features
    
    def extract_product_benefits(self, soup):
        """Extract product benefits"""
        benefits = []
        benefit_selectors = [
            '.benefits li',
            '.product-benefits li',
            '.advantages li',
            '.why-choose li'
        ]
        
        for selector in benefit_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text(strip=True)
                if text and len(text) > 5:
                    benefits.append(text)
        
        return benefits[:10]  # Return top 10 benefits
    
    def extract_premium_info(self, soup):
        """Extract premium information"""
        premium_info = {}
        price_selectors = selectors.get('price', '').split(', ')
        
        for selector in price_selectors:
            elements = soup.select(selector)
            if elements:
                price_text = elements[0].get_text(strip=True)
                if price_text:
                    premium_info['price_text'] = price_text
                    # Try to extract numeric values
                    numbers = re.findall(r'[\d,]+\.?\d*', price_text)
                    if numbers:
                        premium_info['price_numeric'] = numbers[0]
                    break
        
        return premium_info
    
    def extract_eligibility_info(self, soup):
        """Extract eligibility information"""
        eligibility = []
        eligibility_selectors = [
            '.eligibility li',
            '.requirements li',
            '.conditions li',
            '.who-can-buy li'
        ]
        
        for selector in eligibility_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text(strip=True)
                if text and len(text) > 5:
                    eligibility.append(text)
        
        return eligibility
    
    def extract_exclusions(self, soup):
        """Extract exclusions"""
        exclusions = []
        exclusion_selectors = [
            '.exclusions li',
            '.limitations li',
            '.not-covered li',
            '.excluded li'
        ]
        
        for selector in exclusion_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text(strip=True)
                if text and len(text) > 5:
                    exclusions.append(text)
        
        return exclusions
    
    def is_valid_product_url(self, url):
        """Check if URL is a valid product URL"""
        invalid_patterns = [
            '#', 'javascript:', 'tel:', 'mailto:', 'pdf', 'download',
            'about:', 'contact', 'career', 'news', 'blog'
        ]
        
        for pattern in invalid_patterns:
            if pattern in url.lower():
                return False
        
        return True
    
    def save_company_info(self, company_key, company_info):
        """Save company information to database"""
        try:
            # Check if company exists
            existing_company = self.session.query(InsuranceCompany).filter(
                InsuranceCompany.name == company_info['name']
            ).first()
            
            if existing_company:
                # Update existing company
                for key, value in company_info.items():
                    if hasattr(existing_company, key):
                        setattr(existing_company, key, value)
                existing_company.updated_at = datetime.utcnow()
                logger.info(f"Updated company: {company_info['name']}")
            else:
                # Create new company
                company = InsuranceCompany(**company_info)
                self.session.add(company)
                logger.info(f"Created new company: {company_info['name']}")
            
            self.session.commit()
            return True
            
        except Exception as e:
            logger.error(f"Error saving company info: {str(e)}")
            self.session.rollback()
            return False
    
    def save_product_info(self, company_key, product_data):
        """Save product information to database"""
        try:
            # Get company
            company = self.session.query(InsuranceCompany).filter(
                InsuranceCompany.name == self.companies_config[company_key]['name']
            ).first()
            
            if not company:
                logger.error(f"Company not found: {company_key}")
                return None
            
            # Check if product exists
            existing_product = self.session.query(InsuranceProduct).filter(
                InsuranceProduct.name == product_data['name']
            ).first()
            
            if existing_product:
                # Update existing product
                result = 'updated'
                existing_product.short_description = product_data.get('description', '')
                existing_product.full_description = product_data.get('description', '')
                existing_product.features = product_data.get('features', [])
                existing_product.benefits = product_data.get('benefits', [])
                existing_product.exclusions = product_data.get('exclusions', [])
                existing_product.updated_at = datetime.utcnow()
                
                logger.info(f"Updated product: {product_data['name']}")
            else:
                # Create new product
                product = InsuranceProduct(
                    company_id=company.id,
                    name=product_data['name'],
                    short_description=product_data.get('description', ''),
                    full_description=product_data.get('description', ''),
                    features=product_data.get('features', []),
                    benefits=product_data.get('benefits', []),
                    exclusions=product_data.get('exclusions', [])
                )
                self.session.add(product)
                result = 'created'
                logger.info(f"Created new product: {product_data['name']}")
            
            self.session.commit()
            return result
            
        except Exception as e:
            logger.error(f"Error saving product info: {str(e)}")
            self.session.rollback()
            return None
    
    def scrape_all_companies(self):
        """Scrape information for all configured companies"""
        logger.info("Starting to scrape all companies...")
        
        for company_key in self.companies_config.keys():
            try:
                # Scrape company info
                self.scrape_company_info(company_key)
                time.sleep(self.request_delay)
                
                # Scrape products
                self.scrape_products(company_key)
                time.sleep(self.request_delay)
                
            except Exception as e:
                logger.error(f"Error scraping {company_key}: {str(e)}")
                continue
        
        logger.info("Finished scraping all companies")
    
    def scrape_specific_company(self, company_key):
        """Scrape information for a specific company"""
        if company_key not in self.companies_config:
            logger.error(f"Company not configured: {company_key}")
            return False
        
        try:
            # Scrape company info
            self.scrape_company_info(company_key)
            time.sleep(self.request_delay)
            
            # Scrape products
            self.scrape_products(company_key)
            
            return True
            
        except Exception as e:
            logger.error(f"Error scraping {company_key}: {str(e)}")
            return False
    
    def get_scraping_stats(self):
        """Get scraping statistics"""
        try:
            stats = {
                'total_companies': self.session.query(InsuranceCompany).count(),
                'total_products': self.session.query(InsuranceProduct).count(),
                'scraping_logs': []
            }
            
            # Get recent scraping logs
            logs = self.session.query(ScrapingLog).order_by(
                ScrapingLog.created_at.desc()
            ).limit(10).all()
            
            for log in logs:
                stats['scraping_logs'].append({
                    'source': log.source,
                    'scraping_type': log.scraping_type,
                    'status': log.status,
                    'items_scraped': log.items_scraped,
                    'created_at': log.created_at.isoformat()
                })
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting scraping stats: {str(e)}")
            return {}
    
    def close(self):
        """Close database connection"""
        self.session.close()

# Example usage
if __name__ == "__main__":
    scraper = InsuranceScraper()
    
    try:
        # Scrape all companies
        scraper.scrape_all_companies()
        
        # Get scraping statistics
        stats = scraper.get_scraping_stats()
        print("\\nScraping Statistics:")
        print(f"Total Companies: {stats['total_companies']}")
        print(f"Total Products: {stats['total_products']}")
        print("\\nRecent Scraping Logs:")
        for log in stats['scraping_logs']:
            print(f"  {log['source']} - {log['scraping_type']} - {log['status']} ({log['items_scraped']} items)")
        
    except KeyboardInterrupt:
        logger.info("Scraping interrupted by user")
    except Exception as e:
        logger.error(f"Scraping failed: {str(e)}")
    finally:
        scraper.close()