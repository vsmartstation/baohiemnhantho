"""
Main Flask Application for Insurance Chatbot
Ứng dụng Flask chính cho hệ thống chatbot bảo hiểm nhân thọ
"""

from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import sys
from datetime import datetime
import logging
from logging.handlers import RotatingFileHandler

# Import blueprints and modules
from enhanced_chatbot import enhanced_chatbot_bp
from product_api import product_bp
from database_schema import create_database_engine, Base, InsuranceCompany, InsuranceProduct

# Initialize Flask app
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///insurance_products.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Enable CORS
CORS(app, resources={
    r"/api/*": {
        "origins": ["*"],
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type"]
    }
})

# Register blueprints
app.register_blueprint(enhanced_chatbot_bp, url_prefix='/api')
app.register_blueprint(product_bp, url_prefix='/api')

# Setup logging
if not app.debug:
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    file_handler = RotatingFileHandler('logs/app.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)

# Initialize database
@app.before_first_request
def create_tables():
    """Create database tables before first request"""
    try:
        engine = create_database_engine()
        Base.metadata.create_all(engine)
        app.logger.info("Database tables created successfully")
    except Exception as e:
        app.logger.error(f"Error creating database tables: {str(e)}")

# Security headers
@app.after_request
def add_security_headers(response):
    """Add security headers to all responses"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    if request.is_secure:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response

# Routes
@app.route('/')
def index():
    """Main page - enhanced chatbot"""
    return render_template('enhanced_chatbot.html')

@app.route('/compare')
def compare():
    """Product comparison page"""
    return render_template('product_comparison.html')

@app.route('/demo')
def demo():
    """Demo page"""
    return render_template('index.html')

@app.route('/health')
def health():
    """Health check endpoint"""
    try:
        # Check database connection
        from database_schema import get_session
        session = get_session(create_database_engine())
        companies_count = session.query(InsuranceCompany).count()
        products_count = session.query(InsuranceProduct).count()
        session.close()
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '2.0.0',
            'database': 'connected',
            'companies_count': companies_count,
            'products_count': products_count,
            'uptime': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@app.route('/metrics')
def metrics():
    """Application metrics"""
    try:
        from database_schema import get_session
        session = get_session(create_database_engine())
        
        metrics_data = {
            'database': {
                'companies': session.query(InsuranceCompany).count(),
                'products': session.query(InsuranceProduct).count(),
                'last_updated': datetime.utcnow().isoformat()
            },
            'system': {
                'python_version': sys.version,
                'flask_version': Flask.__version__,
                'environment': os.environ.get('FLASK_ENV', 'development')
            },
            'timestamp': datetime.utcnow().isoformat()
        }
        
        session.close()
        return jsonify(metrics_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/static/<path:path>')
def serve_static(path):
    """Serve static files"""
    return send_from_directory('static', path)

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Not found', 'message': 'The requested resource was not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    app.logger.error(f"Internal server error: {str(error)}")
    return jsonify({'error': 'Internal server error', 'message': 'An unexpected error occurred'}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    """Handle all other exceptions"""
    app.logger.error(f"Unhandled exception: {str(e)}")
    return jsonify({'error': 'Server error', 'message': str(e)}), 500

# CLI commands
@app.cli.command()
def init_db():
    """Initialize database with sample data"""
    try:
        from database_schema import get_session, initialize_sample_data
        engine = create_database_engine()
        session = get_session(engine)
        initialize_sample_data(session)
        session.close()
        print("Database initialized successfully!")
    except Exception as e:
        print(f"Error initializing database: {str(e)}")

@app.cli.command()
def scrape_data():
    """Scrape data from insurance companies"""
    try:
        from insurance_scraper import InsuranceScraper
        scraper = InsuranceScraper()
        scraper.scrape_all_companies()
        scraper.close()
        print("Data scraping completed!")
    except Exception as e:
        print(f"Error scraping data: {str(e)}")

@app.cli.command()
def run_scraper():
    """Run specific company scraper"""
    import click
    company = click.prompt('Enter company key (prudential/manulife/baoviet/daiichi/aia)', type=str)
    
    try:
        from insurance_scraper import InsuranceScraper
        scraper = InsuranceScraper()
        scraper.scrape_specific_company(company)
        scraper.close()
        print(f"Scraped data for {company}!")
    except Exception as e:
        print(f"Error scraping {company}: {str(e)}")

# Performance monitoring middleware
@app.before_request
def before_request():
    """Log request information"""
    app.logger.info(f"Request: {request.method} {request.path} from {request.remote_addr}")

@app.after_request
def after_request(response):
    """Log response information"""
    app.logger.info(f"Response: {response.status_code} for {request.path}")
    return response

# Context processor for templates
@app.context_processor
def inject_globals():
    """Inject global variables into templates"""
    return {
        'current_year': datetime.now().year,
        'environment': os.environ.get('FLASK_ENV', 'development'),
        'version': '2.0.0'
    }

if __name__ == '__main__':
    # Development server
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    print(f"Starting Insurance Chatbot on port {port}")
    print(f"Environment: {os.environ.get('FLASK_ENV', 'development')}")
    print(f"Database: {app.config['SQLALCHEMY_DATABASE_URI']}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)