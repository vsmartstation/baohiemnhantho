"""
Database Schema for Insurance Products Comparison System
Hệ thống cơ sở dữ liệu để lưu trữ thông tin sản phẩm bảo hiểm nhân thọ tại Việt Nam
"""

from sqlalchemy import create_engine, Column, Integer, String, Text, Float, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import json

Base = declarative_base()

class InsuranceCompany(Base):
    """Bảng thông tin công ty bảo hiểm"""
    __tablename__ = 'insurance_companies'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    name_en = Column(String(100))
    founded_year = Column(Integer)
    vietnam_entry_year = Column(Integer)
    market_position = Column(String(20))
    headquarters = Column(String(200))
    website = Column(String(200))
    hotline = Column(String(20))
    email = Column(String(100))
    description = Column(Text)
    strengths = Column(JSON)  # List of strengths
    weaknesses = Column(JSON)  # List of weaknesses
    total_assets = Column(Float)  # Tổng tài sản (tỷ VNĐ)
    revenue = Column(Float)  # Doanh thu (tỷ VNĐ)
    number_of_customers = Column(Integer)  # Số khách hàng
    number_of_employees = Column(Integer)  # Số nhân viên
    branches_count = Column(Integer)  # Số chi nhánh
    provinces_coverage = Column(Integer)  # Số tỉnh thành phủ sóng
    rating = Column(Float)  # Đánh giá từ 1-5
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    products = relationship("InsuranceProduct", back_populates="company")
    branches = relationship("CompanyBranch", back_populates="company")

class CompanyBranch(Base):
    """Bảng thông tin chi nhánh công ty bảo hiểm"""
    __tablename__ = 'company_branches'
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('insurance_companies.id'))
    name = Column(String(200), nullable=False)
    address = Column(String(500), nullable=False)
    province = Column(String(50), nullable=False)
    district = Column(String(50))
    phone = Column(String(20))
    email = Column(String(100))
    working_hours = Column(String(200))
    latitude = Column(Float)
    longitude = Column(Float)
    is_headquarters = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    company = relationship("InsuranceCompany", back_populates="branches")

class InsuranceCategory(Base):
    """Bảng danh mục bảo hiểm"""
    __tablename__ = 'insurance_categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    name_en = Column(String(100))
    description = Column(Text)
    icon = Column(String(50))  # Icon name
    color = Column(String(7))  # Hex color code
    parent_id = Column(Integer, ForeignKey('insurance_categories.id'))
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    parent = relationship("InsuranceCategory", remote_side=[id])
    children = relationship("InsuranceCategory")
    products = relationship("InsuranceProduct", back_populates="category")

class InsuranceProduct(Base):
    """Bảng thông tin sản phẩm bảo hiểm"""
    __tablename__ = 'insurance_products'
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('insurance_companies.id'))
    category_id = Column(Integer, ForeignKey('insurance_categories.id'))
    name = Column(String(200), nullable=False)
    name_en = Column(String(200))
    code = Column(String(50), unique=True)
    slug = Column(String(200), unique=True)
    short_description = Column(Text)
    full_description = Column(Text)
    product_type = Column(String(50))  # traditional, investment, mixed
    target_customers = Column(JSON)  # List of target customer groups
    min_age = Column(Integer)
    max_age = Column(Integer)
    min_coverage_amount = Column(Float)  # Số tiền bảo hiểm tối thiểu (triệu VNĐ)
    max_coverage_amount = Column(Float)  # Số tiền bảo hiểm tối đa (triệu VNĐ)
    currency = Column(String(3), default='VND')
    policy_term_min = Column(Integer)  # Thời hạn hợp đồng tối thiểu (năm)
    policy_term_max = Column(Integer)  # Thời hạn hợp đồng tối đa (năm)
    premium_payment_methods = Column(JSON)  # List of payment methods
    waiting_period = Column(Integer)  # Thời gian chờ (ngày)
    grace_period = Column(Integer)  # Thời gian gia hạn (ngày)
    free_look_period = Column(Integer)  # Thời gian xem xét miễn phí (ngày)
    surrender_value = Column(JSON)  # Thông tin giá trị hoàn lại
    loan_available = Column(Boolean, default=False)
    max_loan_percentage = Column(Float)  # Tỷ lệ vay tối đa (%)
    renewal_options = Column(JSON)  # Tùy chọn gia hạn
    riders_available = Column(JSON)  # List of available riders
    exclusions = Column(JSON)  # List of exclusions
    benefits = Column(JSON)  # List of benefits
    features = Column(JSON)  # List of features
    pros = Column(JSON)  # List of advantages
    cons = Column(JSON)  # List of disadvantages
    additional_info = Column(JSON)  # Additional information
    is_popular = Column(Boolean, default=False)
    is_recommended = Column(Boolean, default=False)
    view_count = Column(Integer, default=0)
    rating = Column(Float)  # Đánh giá từ 1-5
    number_of_reviews = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("InsuranceCompany", back_populates="products")
    category = relationship("InsuranceCategory", back_populates="products")
    premium_plans = relationship("PremiumPlan", back_populates="product")
    benefits_details = relationship("ProductBenefit", back_populates="product")
    comparisons = relationship("ProductComparison", back_populates="products")

class PremiumPlan(Base):
    """Bảng thông tin kế hoạch phí bảo hiểm"""
    __tablename__ = 'premium_plans'
    
    id = Column(Integer, primary_key=True)
    product_id = Column(Integer, ForeignKey('insurance_products.id'))
    name = Column(String(100), nullable=False)
    description = Column(Text)
    age_from = Column(Integer)
    age_to = Column(Integer)
    gender = Column(String(10))  # male, female, both
    smoking_status = Column(String(20))  # smoker, non-smoker, both
    coverage_amount = Column(Float)  # Số tiền bảo hiểm (triệu VNĐ)
    premium_monthly = Column(Float)  # Phí hàng tháng (nghìn VNĐ)
    premium_quarterly = Column(Float)  # Phí hàng quý (nghìn VNĐ)
    premium_yearly = Column(Float)  # Phí hàng năm (nghìn VNĐ)
    premium_single = Column(Float)  # Phí một lần (nghìn VNĐ)
    currency = Column(String(3), default='VND')
    payment_frequency = Column(JSON)  # List of available payment frequencies
    first_year_bonus = Column(Float)  # Thưởng năm đầu tiên (%)
    renewal_bonus = Column(Float)  # Thưởng gia hạn (%)
    guaranteed_return = Column(Float)  # Lợi nhuận đảm bảo (%)
    projected_return = Column(JSON)  # Lợi nhuận dự kiến theo năm
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    product = relationship("InsuranceProduct", back_populates="premium_plans")

class ProductBenefit(Base):
    """Bảng thông tin quyền lợi sản phẩm"""
    __tablename__ = 'product_benefits'
    
    id = Column(Integer, primary_key=True)
    product_id = Column(Integer, ForeignKey('insurance_products.id'))
    name = Column(String(200), nullable=False)
    description = Column(Text)
    benefit_type = Column(String(50))  # death, disability, illness, maturity, etc.
    coverage_amount = Column(Float)  # Số tiền bảo hiểm (triệu VNĐ)
    coverage_percentage = Column(Float)  # Tỷ lệ bảo hiểm (%)
    waiting_period = Column(Integer)  # Thời gian chờ (ngày)
    survival_period = Column(Integer)  # Thời gian sống sót (ngày)
    benefit_term = Column(Integer)  # Thời hạn hưởng quyền lợi (năm)
    conditions = Column(JSON)  # Điều kiện hưởng quyền lợi
    exclusions = Column(JSON)  # Các trường hợp loại trừ
    claim_process = Column(Text)  # Quy trình khiếu nại
    required_documents = Column(JSON)  # Tài liệu cần thiết
    is_mandatory = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    product = relationship("InsuranceProduct", back_populates="benefits_details")

class ProductComparison(Base):
    """Bảng lưu trữ lịch sử so sánh sản phẩm"""
    __tablename__ = 'product_comparisons'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(String(100))  # Session ID for anonymous users
    user_id = Column(Integer, nullable=True)  # User ID for registered users
    products = Column(JSON)  # List of product IDs being compared
    comparison_criteria = Column(JSON)  # List of criteria for comparison
    comparison_result = Column(JSON)  # Comparison result data
    user_preferences = Column(JSON)  # User preferences and inputs
    recommendations = Column(JSON)  # AI recommendations
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)  # When comparison data expires
    
    # Relationships
    products_rel = relationship("InsuranceProduct", back_populates="comparisons")

class UserQuery(Base):
    """Bảng lưu trữ câu hỏi của người dùng"""
    __tablename__ = 'user_queries'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(String(100))
    user_id = Column(Integer, nullable=True)
    query_text = Column(Text, nullable=False)
    query_type = Column(String(50))  # general, product_comparison, calculation, etc.
    intent = Column(String(100))  # Detected intent
    entities = Column(JSON)  # Extracted entities
    response_text = Column(Text)
    response_type = Column(String(50))  # text, product_list, comparison, etc.
    satisfaction_score = Column(Float)  # User satisfaction score
    is_resolved = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
class SystemConfig(Base):
    """Bảng cấu hình hệ thống"""
    __tablename__ = 'system_configs'
    
    id = Column(Integer, primary_key=True)
    config_key = Column(String(100), nullable=False, unique=True)
    config_value = Column(Text)
    description = Column(Text)
    data_type = Column(String(20))  # string, integer, float, boolean, json
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ScrapingLog(Base):
    """Bảng log hoạt động scraping"""
    __tablename__ = 'scraping_logs'
    
    id = Column(Integer, primary_key=True)
    source = Column(String(100), nullable=False)  # Company website or data source
    scraping_type = Column(String(50))  # products, companies, rates, etc.
    status = Column(String(20))  # success, failed, partial
    items_scraped = Column(Integer, default=0)
    items_updated = Column(Integer, default=0)
    items_created = Column(Integer, default=0)
    errors = Column(JSON)  # List of errors encountered
    execution_time = Column(Float)  # Execution time in seconds
    created_at = Column(DateTime, default=datetime.utcnow)
    
class PerformanceMetric(Base):
    """Bảng lưu trữ metrics hiệu năng"""
    __tablename__ = 'performance_metrics'
    
    id = Column(Integer, primary_key=True)
    metric_name = Column(String(100), nullable=False)
    metric_value = Column(Float)
    metric_unit = Column(String(20))
    timestamp = Column(DateTime, default=datetime.utcnow)
    additional_data = Column(JSON)

def create_database_engine(database_url="sqlite:///insurance_products.db"):
    """Tạo database engine"""
    engine = create_engine(database_url)
    Base.metadata.create_all(engine)
    return engine

def get_session(engine):
    """Tạo database session"""
    Session = sessionmaker(bind=engine)
    return Session()

def initialize_sample_data(session):
    """Khởi tạo dữ liệu mẫu"""
    # Sample companies
    companies = [
        {
            'name': 'Prudential Việt Nam',
            'founded_year': 1848,
            'vietnam_entry_year': 1999,
            'market_position': 'Top 1',
            'website': 'https://www.prudential.com.vn',
            'hotline': '1800 588 826',
            'description': 'Công ty bảo hiểm nhân thọ hàng đầu Việt Nam',
            'strengths': ['175 năm kinh nghiệm', 'Sản phẩm đa dạng', 'Dịch vụ xuất sắc'],
            'rating': 4.8
        },
        {
            'name': 'Manulife Việt Nam',
            'founded_year': 1887,
            'vietnam_entry_year': 1999,
            'market_position': 'Top 3',
            'website': 'https://www.manulife.com.vn',
            'hotline': '1900 6069',
            'description': 'Công ty bảo hiểm Canada uy tín',
            'strengths': ['Đầu tư mạnh', 'Fintech', 'Dịch vụ cao cấp'],
            'rating': 4.6
        },
        {
            'name': 'Bảo Việt',
            'founded_year': 1965,
            'vietnam_entry_year': 1965,
            'market_position': 'Top 5',
            'website': 'https://www.baoviet.com.vn',
            'hotline': '1900 55 88 99',
            'description': 'Tập đoàn tài chính nhà nước',
            'strengths': ['Uy tín cao', 'Mạng lưới rộng', 'Giá cả cạnh tranh'],
            'rating': 4.5
        }
    ]
    
    for company_data in companies:
        company = InsuranceCompany(**company_data)
        session.add(company)
    
    # Sample categories
    categories = [
        {'name': 'Bảo hiểm nhân thọ truyền thống', 'description': 'Bảo hiểm bảo vệ tài chính cơ bản'},
        {'name': 'Bảo hiểm nhân thọ đầu tư', 'description': 'Bảo hiểm kết hợp đầu tư'},
        {'name': 'Bảo hiểm nhân thọ hỗn hợp', 'description': 'Bảo hiểm vừa bảo vệ vừa tích lũy'},
        {'name': 'Bảo hiểm sức khỏe', 'description': 'Bảo hiểm chi phí y tế'},
        {'name': 'Bảo hiểm giáo dục', 'description': 'Bảo hiểm quỹ giáo dục con cái'},
        {'name': 'Bảo hiểm hưu trí', 'description': 'Bảo hiểm quỹ hưu trí'}
    ]
    
    for category_data in categories:
        category = InsuranceCategory(**category_data)
        session.add(category)
    
    session.commit()
    print("Sample data initialized successfully!")

if __name__ == "__main__":
    # Tạo database
    engine = create_database_engine()
    print("Database created successfully!")
    
    # Tạo session
    session = get_session(engine)
    
    # Khởi tạo dữ liệu mẫu
    initialize_sample_data(session)
    
    # Đóng session
    session.close()
    
    print("Database setup completed!")